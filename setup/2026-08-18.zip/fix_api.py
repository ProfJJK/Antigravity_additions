import os
scripts = [r'D:\Gdrive\__agentic\.prompts\.scripts\audit.py', r'D:\Gdrive\__agentic\.prompts\.scripts\improv.py', r'D:\Gdrive\__agentic\.prompts\.scripts\test.py']
replacement = '# PURGE API KEY: Force google.antigravity to use internal IDE agents instead of external free-tier API\nos.environ.pop("GEMINI_API_KEY", None)\nos.environ["GEMINI_API_KEY"] = "dummy_ide_key"\n'
for script in scripts:
    with open(script, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    cleaned_lines = []
    for line in lines:
        if 'GEMINI_API_KEY' not in line and 'PURGE API KEY' not in line and 'CORE_API_KEY' not in line:
            cleaned_lines.append(line)
    insert_idx = 0
    for i, line in enumerate(cleaned_lines):
        if line.startswith('import ') or line.startswith('from '):
            insert_idx = i + 1
    cleaned_lines.insert(insert_idx, '\n' + replacement + '\n')
    with open(script, 'w', encoding='utf-8') as f:
        f.writelines(cleaned_lines)
    print(f'Fixed API logic in {os.path.basename(script)}')
