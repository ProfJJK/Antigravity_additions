import os
os.environ.pop('GEMINI_API_KEY', None)
import asyncio
from google.antigravity import Agent, LocalAgentConfig

async def main():
    async with Agent(config=LocalAgentConfig(enable_subagents=True)) as agent:
        print((await agent.chat('test')).text)

asyncio.run(main())
