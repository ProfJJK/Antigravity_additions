import argparse
import requests
import json
import time
import os

API_KEY = "rfab__UjFMW_yTAr2PWqe_d8p5wAqvYtIWIEzxgXs9JV4Xy4"
URL = "https://api.rfab.ai/api/image-generation/generate"

def generate_image(prompt, model_id, output_path):
    headers = {
        "X-API-Key": API_KEY,
        "Content-Type": "application/json"
    }
    payload = {
        "prompt": prompt,
        "model_id": model_id
    }
    
    print(f"Sending request to rfab.ai for model '{model_id}'...")
    response = requests.post(URL, headers=headers, json=payload)
    
    if response.status_code == 200:
        data = response.json()
        print("Response received:")
        print(json.dumps(data, indent=2))
        
        # Typically the response will contain an image URL or base64 data.
        # We will assume it contains an image URL for now.
        if "url" in data:
            image_url = data["url"]
            print(f"Downloading image from {image_url}...")
            img_response = requests.get(image_url)
            if img_response.status_code == 200:
                with open(output_path, 'wb') as f:
                    f.write(img_response.content)
                print(f"Image successfully saved to {output_path}")
            else:
                print(f"Failed to download image. Status code: {img_response.status_code}")
        elif "image" in data or "base64" in data:
            # Handle base64 logic here if they return base64
            pass
        else:
            print("Could not determine how to download the image from the response.")
    else:
        print(f"API Error ({response.status_code}): {response.text}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate image using rfab.ai")
    parser.add_argument("--prompt", type=str, required=True, help="Image prompt")
    parser.add_argument("--model", type=str, default="flux-schnell", help="Model ID")
    parser.add_argument("--out", type=str, default="generated_image.png", help="Output path")
    args = parser.parse_args()
    
    generate_image(args.prompt, args.model, args.out)
