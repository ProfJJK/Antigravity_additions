$proc = Get-Process -Id $PID
$startTimeStr = $proc.StartTime.ToString("o")
$json = "[{""PID"":123,""StartTime"":""$startTimeStr""}]"
$agents = $json | ConvertFrom-Json
$agent = $agents[0]
$type = $agent.StartTime.GetType().Name
$result = ($startTimeStr -eq $agent.StartTime)
Write-Output "String: $startTimeStr"
Write-Output "Type: $type"
Write-Output "Result: $result"
