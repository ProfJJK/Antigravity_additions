import * as vscode from 'vscode';
import * as http from 'http';
import * as fs from 'fs';
import * as path from 'path';

// ── Configuration ──────────────────────────────────────────────────────────
const DEFAULT_PORT = 23741;
const OLLAMA_BASE = 'http://127.0.0.1:11434';
const PORT_FILE = path.join(
    process.env.APPDATA || path.join(process.env.HOME || '', '.config'),
    '.gemini', 'antigravity', 'copilot-bridge', '.port'
);

let httpServer: http.Server | undefined;
let activePort: number = DEFAULT_PORT;
const outputChannel = vscode.window.createOutputChannel('Copilot Bridge');

// ── Activation ─────────────────────────────────────────────────────────────
export function activate(context: vscode.ExtensionContext) {
    outputChannel.appendLine('[Copilot Bridge] Extension activating...');

    context.subscriptions.push(
        vscode.commands.registerCommand('copilot-bridge.status', async () => {
            try {
                const models = await vscode.lm.selectChatModels({ vendor: 'copilot' });
                const modelList = models.map(m => `  • ${m.name} (${m.family})`).join('\n');
                vscode.window.showInformationMessage(
                    `Copilot Bridge running on port ${activePort}\n` +
                    `Models available: ${models.length}\n${modelList}`
                );
            } catch (err: any) {
                vscode.window.showErrorMessage(`Copilot Bridge error: ${err.message}`);
            }
        })
    );

    startServer(context);
}

// ── HTTP Server ────────────────────────────────────────────────────────────
function startServer(context: vscode.ExtensionContext) {
    httpServer = http.createServer(async (req, res) => {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
        res.setHeader('Content-Type', 'application/json');

        if (req.method === 'OPTIONS') {
            res.writeHead(204);
            res.end();
            return;
        }

        const url = new URL(req.url || '/', `http://127.0.0.1:${activePort}`);

        try {
            switch (url.pathname) {
                // ── Copilot Routes ──
                case '/api/status':
                    if (req.method === 'GET') { await handleStatus(res); } else { respond(res, 405, { error: 'Method not allowed' }); }
                    break;
                case '/api/models':
                    if (req.method === 'GET') { await handleModels(res); } else { respond(res, 405, { error: 'Method not allowed' }); }
                    break;
                case '/api/generate':
                    if (req.method === 'POST') { await handleGenerate(req, res); } else { respond(res, 405, { error: 'Method not allowed' }); }
                    break;

                // ── All-Vendor Routes ──
                case '/api/all-models':
                    if (req.method === 'GET') { await handleAllModels(res); } else { respond(res, 405, { error: 'Method not allowed' }); }
                    break;

                // ── Ollama Routes ──
                case '/api/ollama/models':
                    if (req.method === 'GET') { await handleOllamaModels(res); } else { respond(res, 405, { error: 'Method not allowed' }); }
                    break;
                case '/api/ollama/generate':
                    if (req.method === 'POST') { await handleOllamaGenerate(req, res); } else { respond(res, 405, { error: 'Method not allowed' }); }
                    break;

                default:
                    respond(res, 404, { error: 'Not found' });
            }
        } catch (err: any) {
            outputChannel.appendLine(`[ERROR] ${err.message}`);
            respond(res, 500, { error: err.message });
        }
    });

    httpServer.listen(DEFAULT_PORT, '127.0.0.1', () => {
        activePort = DEFAULT_PORT;
        onServerReady(context);
    });

    httpServer.on('error', (err: NodeJS.ErrnoException) => {
        if (err.code === 'EADDRINUSE') {
            outputChannel.appendLine(`[WARN] Port ${DEFAULT_PORT} in use, trying ephemeral port...`);
            httpServer!.listen(0, '127.0.0.1', () => {
                const addr = httpServer!.address();
                if (addr && typeof addr !== 'string') {
                    activePort = addr.port;
                    onServerReady(context);
                }
            });
        } else {
            outputChannel.appendLine(`[ERROR] Server failed: ${err.message}`);
            vscode.window.showErrorMessage(`Copilot Bridge server failed: ${err.message}`);
        }
    });
}

function onServerReady(context: vscode.ExtensionContext) {
    const dir = path.dirname(PORT_FILE);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(PORT_FILE, activePort.toString(), 'utf-8');

    outputChannel.appendLine(`[Copilot Bridge] HTTP server listening on 127.0.0.1:${activePort}`);
    outputChannel.appendLine(`[Copilot Bridge] Port file written to ${PORT_FILE}`);
    vscode.window.showInformationMessage(`Copilot Bridge active on port ${activePort}`);

    context.subscriptions.push({
        dispose: () => {
            httpServer?.close();
            try { fs.unlinkSync(PORT_FILE); } catch { /* ignore */ }
            outputChannel.appendLine('[Copilot Bridge] Server stopped.');
        }
    });
}

// ═══════════════════════════════════════════════════════════════════════════
//  COPILOT HANDLERS
// ═══════════════════════════════════════════════════════════════════════════

async function handleStatus(res: http.ServerResponse) {
    try {
        const copilotModels = await vscode.lm.selectChatModels({ vendor: 'copilot' });
        let ollamaAvailable = false;
        try {
            const ollamaResp = await ollamaRequest('GET', '/api/tags');
            ollamaAvailable = true;
        } catch { /* Ollama not running */ }

        respond(res, 200, {
            status: 'running',
            port: activePort,
            copilot_available: copilotModels.length > 0,
            copilot_model_count: copilotModels.length,
            ollama_available: ollamaAvailable
        });
    } catch (err: any) {
        respond(res, 200, {
            status: 'running',
            port: activePort,
            copilot_available: false,
            ollama_available: false,
            error: err.message
        });
    }
}

async function handleModels(res: http.ServerResponse) {
    const models = await vscode.lm.selectChatModels({ vendor: 'copilot' });
    respond(res, 200, {
        models: models.map(m => ({
            id: m.id, name: m.name, family: m.family,
            vendor: m.vendor, version: m.version, maxInputTokens: m.maxInputTokens
        }))
    });
}

async function handleAllModels(res: http.ServerResponse) {
    // Query ALL vendors (Copilot, Ollama extensions, etc.)
    const allModels = await vscode.lm.selectChatModels();
    respond(res, 200, {
        models: allModels.map(m => ({
            id: m.id, name: m.name, family: m.family,
            vendor: m.vendor, version: m.version, maxInputTokens: m.maxInputTokens
        }))
    });
}

async function handleGenerate(req: http.IncomingMessage, res: http.ServerResponse) {
    const body = await readBody(req);
    let parsed: any;
    try {
        parsed = JSON.parse(body);
    } catch {
        respond(res, 400, { error: 'Invalid JSON body' });
        return;
    }

    const { prompt, system_message, model_family, language } = parsed;

    if (!prompt) {
        respond(res, 400, { error: 'Missing required field: prompt' });
        return;
    }

    outputChannel.appendLine(`[COPILOT REQ] prompt="${prompt.substring(0, 80)}..." model_family=${model_family || 'auto'} lang=${language || 'auto'}`);

    const selector: vscode.LanguageModelChatSelector = { vendor: 'copilot' };
    if (model_family) {
        (selector as any).family = model_family;
    }

    const models = await vscode.lm.selectChatModels(selector);
    if (models.length === 0) {
        respond(res, 503, {
            error: 'No Copilot models available. Ensure GitHub Copilot is installed and you are signed in.'
        });
        return;
    }

    const model = models[0];
    outputChannel.appendLine(`[COPILOT MODEL] Using: ${model.name} (${model.family})`);

    const messages: vscode.LanguageModelChatMessage[] = [];
    if (system_message) {
        messages.push(vscode.LanguageModelChatMessage.User(`[System Instructions]\n${system_message}`));
    }
    let userPrompt = prompt;
    if (language) {
        userPrompt = `Language: ${language}\n\n${prompt}`;
    }
    messages.push(vscode.LanguageModelChatMessage.User(userPrompt));

    const tokenSource = new vscode.CancellationTokenSource();
    const timeout = setTimeout(() => tokenSource.cancel(), 120_000);

    try {
        const response = await model.sendRequest(
            messages,
            { justification: 'Antigravity agent requesting code generation via Copilot Bridge.' },
            tokenSource.token
        );

        let fullText = '';
        for await (const chunk of response.text) {
            fullText += chunk;
        }
        clearTimeout(timeout);

        outputChannel.appendLine(`[COPILOT RES] ${fullText.length} chars from ${model.name}`);
        respond(res, 200, {
            text: fullText,
            model: { id: model.id, name: model.name, family: model.family },
            provider: 'copilot'
        });
    } catch (err: any) {
        clearTimeout(timeout);
        if (err instanceof vscode.LanguageModelError) {
            outputChannel.appendLine(`[COPILOT LM ERROR] ${err.name}: ${err.message}`);
            respond(res, 503, { error: err.message, type: err.name, provider: 'copilot' });
        } else {
            throw err;
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════
//  OLLAMA HANDLERS
// ═══════════════════════════════════════════════════════════════════════════

async function handleOllamaModels(res: http.ServerResponse) {
    try {
        const data = await ollamaRequest('GET', '/api/tags');
        const models = (data.models || []).map((m: any) => ({
            name: m.name,
            model: m.model,
            size: m.size,
            parameter_size: m.details?.parameter_size,
            quantization_level: m.details?.quantization_level,
            family: m.details?.family,
            modified_at: m.modified_at
        }));
        respond(res, 200, { models });
    } catch (err: any) {
        respond(res, 503, {
            error: `Ollama not reachable at ${OLLAMA_BASE}. Is it running? Detail: ${err.message}`
        });
    }
}

async function handleOllamaGenerate(req: http.IncomingMessage, res: http.ServerResponse) {
    const body = await readBody(req);
    let parsed: any;
    try {
        parsed = JSON.parse(body);
    } catch {
        respond(res, 400, { error: 'Invalid JSON body' });
        return;
    }

    const { prompt, system_message, model, language } = parsed;
    const ollamaModel = model || 'qwen3-coder-128k:latest';

    if (!prompt) {
        respond(res, 400, { error: 'Missing required field: prompt' });
        return;
    }

    outputChannel.appendLine(`[OLLAMA REQ] model=${ollamaModel} prompt="${prompt.substring(0, 80)}..."`);

    // Build messages for Ollama chat API
    const messages: Array<{ role: string; content: string }> = [];
    if (system_message) {
        messages.push({ role: 'system', content: system_message });
    }

    let userContent = prompt;
    if (language) {
        userContent = `Language: ${language}\n\n${prompt}`;
    }
    messages.push({ role: 'user', content: userContent });

    try {
        const data = await ollamaRequest('POST', '/api/chat', {
            model: ollamaModel,
            messages: messages,
            stream: false
        });

        const text = data.message?.content || '';
        outputChannel.appendLine(`[OLLAMA RES] ${text.length} chars from ${ollamaModel}`);

        respond(res, 200, {
            text: text,
            model: {
                id: ollamaModel,
                name: ollamaModel,
                family: 'ollama'
            },
            provider: 'ollama',
            eval_count: data.eval_count,
            eval_duration: data.eval_duration
        });
    } catch (err: any) {
        outputChannel.appendLine(`[OLLAMA ERROR] ${err.message}`);
        respond(res, 503, {
            error: `Ollama request failed: ${err.message}`,
            provider: 'ollama'
        });
    }
}

// ═══════════════════════════════════════════════════════════════════════════
//  OLLAMA HTTP CLIENT
// ═══════════════════════════════════════════════════════════════════════════

function ollamaRequest(method: string, apiPath: string, data?: any): Promise<any> {
    return new Promise((resolve, reject) => {
        const url = new URL(apiPath, OLLAMA_BASE);
        const body = data ? JSON.stringify(data) : undefined;

        const options: http.RequestOptions = {
            hostname: url.hostname,
            port: url.port,
            path: url.pathname,
            method: method,
            headers: {
                'Content-Type': 'application/json',
                ...(body ? { 'Content-Length': Buffer.byteLength(body) } : {})
            },
            timeout: 300_000  // 5 minute timeout for large models
        };

        const req = http.request(options, (res) => {
            let responseData = '';
            res.on('data', (chunk: Buffer) => { responseData += chunk.toString(); });
            res.on('end', () => {
                try {
                    resolve(JSON.parse(responseData));
                } catch {
                    reject(new Error(`Invalid JSON response from Ollama: ${responseData.substring(0, 200)}`));
                }
            });
        });

        req.on('error', reject);
        req.on('timeout', () => {
            req.destroy();
            reject(new Error('Ollama request timed out (5 min)'));
        });

        if (body) {
            req.write(body);
        }
        req.end();
    });
}

// ═══════════════════════════════════════════════════════════════════════════
//  UTILITIES
// ═══════════════════════════════════════════════════════════════════════════

function readBody(req: http.IncomingMessage): Promise<string> {
    return new Promise((resolve, reject) => {
        let data = '';
        req.on('data', (chunk: Buffer) => { data += chunk.toString(); });
        req.on('end', () => resolve(data));
        req.on('error', reject);
    });
}

function respond(res: http.ServerResponse, status: number, body: object) {
    res.writeHead(status);
    res.end(JSON.stringify(body));
}

// ── Deactivation ───────────────────────────────────────────────────────────
export function deactivate() {
    httpServer?.close();
    try { fs.unlinkSync(PORT_FILE); } catch { /* ignore */ }
}
