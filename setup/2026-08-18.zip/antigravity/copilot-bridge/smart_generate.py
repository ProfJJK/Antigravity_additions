import argparse
import sys
import os

# Import the logic directly from copilot_mcp_server
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from mcp.copilot_mcp_server import smart_generate

def main():
    parser = argparse.ArgumentParser(description="CLI wrapper for smart_generate")
    parser.add_argument("--prompt", required=True, help="The generation prompt")
    parser.add_argument("--language", default="python", help="Target language")
    parser.add_argument("--system-message", default="", help="System message")
    parser.add_argument("--model-preference", default="auto", choices=["auto", "copilot", "ollama"])
    
    args = parser.parse_args()
    
    try:
        result = smart_generate(
            prompt=args.prompt,
            language=args.language,
            system_message=args.system_message,
            model_preference=args.model_preference
        )
        print(result)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
