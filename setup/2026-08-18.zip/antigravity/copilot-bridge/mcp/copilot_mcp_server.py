"""
Copilot Bridge MCP Server v2 for Antigravity 2.0
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Proxies tool calls from Antigravity agents to the VS Code Copilot Bridge
extension. Supports both GitHub Copilot and local Ollama models with
intelligent smart routing.

Tools exposed:
  - copilot_generate : Explicit Copilot generation
  - copilot_models   : List Copilot models
  - copilot_status   : Check bridge + Ollama connectivity
  - ollama_generate  : Explicit Ollama generation
  - ollama_models    : List local Ollama models
  - smart_generate   : Auto-routes between Copilot and Ollama
"""

import sys
import json
import logging
import urllib.request
import urllib.error
import os

from mcp.server.fastmcp import FastMCP

# ── Logging (stderr only — stdout is the JSON-RPC stream) ──────────────────
logging.basicConfig(
    level=logging.INFO,
    stream=sys.stderr,
    format="[copilot-mcp] %(levelname)s %(message)s"
)
logger = logging.getLogger("copilot-bridge-mcp")

# ── Configuration ──────────────────────────────────────────────────────────
DEFAULT_PORT = 23741
PORT_FILE = os.path.join(
    os.environ.get("APPDATA", os.path.expanduser("~/.config")),
    ".gemini", "antigravity", "copilot-bridge", ".port"
)
CONFIG_FILE = os.path.join(
    os.environ.get("APPDATA", os.path.expanduser("~/.config")),
    ".gemini", "antigravity", "copilot-bridge", "copilot_bridge_config.json"
)


def _load_config() -> dict:
    """Load the routing configuration."""
    default_config = {
        "routing": {
            "small_task_token_threshold": 32000,
            "default_ollama_model": "qwen3-coder-128k:latest",
            "default_copilot_model": "auto",
            "enable_exhaustion_fallback": True,
            "exhaustion_error_signatures": [
                "rate_limit", "quota", "insufficient", "429", "403"
            ]
        }
    }
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"Could not load config: {e}, using defaults")
    return default_config


# ── FastMCP Server ─────────────────────────────────────────────────────────
mcp = FastMCP("GitHub Copilot Bridge")


def _get_port() -> int:
    """Discover the VS Code extension's HTTP port."""
    if os.path.exists(PORT_FILE):
        try:
            with open(PORT_FILE, "r") as f:
                port = int(f.read().strip())
                return port
        except Exception:
            pass
    return DEFAULT_PORT


def _bridge_request(method: str, path: str, data: dict | None = None, timeout: int = 120) -> dict:
    """Make an HTTP request to the VS Code Copilot Bridge extension."""
    port = _get_port()
    url = f"http://127.0.0.1:{port}{path}"

    headers = {"Content-Type": "application/json"}
    body = json.dumps(data).encode("utf-8") if data else None

    req = urllib.request.Request(url, data=body, headers=headers, method=method)

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        # Read the error response body for detailed error info
        error_body = ""
        try:
            error_body = e.read().decode("utf-8")
        except Exception:
            pass
        raise RuntimeError(
            f"Bridge HTTP error {e.code}: {error_body or e.reason}"
        )
    except urllib.error.URLError as e:
        raise RuntimeError(
            f"Cannot connect to VS Code Copilot Bridge on port {port}. "
            "Ensure VS Code is open with the Copilot Bridge extension installed and activated. "
            f"Detail: {e}"
        )


def _is_token_exhaustion(error_message: str) -> bool:
    """Check if an error indicates Copilot token/quota exhaustion."""
    config = _load_config()
    signatures = config.get("routing", {}).get("exhaustion_error_signatures", [])
    error_lower = error_message.lower()
    return any(sig.lower() in error_lower for sig in signatures)


def _estimate_tokens(text: str) -> int:
    """Rough token estimate: ~4 chars per token for English/code."""
    return len(text) // 4


# ═══════════════════════════════════════════════════════════════════════════
#  COPILOT TOOLS
# ═══════════════════════════════════════════════════════════════════════════

@mcp.tool()
def copilot_generate(
    prompt: str,
    language: str = "python",
    system_message: str = "",
    model_family: str = ""
) -> str:
    """
    Generate code or text using GitHub Copilot via the VS Code bridge.

    Args:
        prompt: The generation prompt or coding task description.
        language: Target programming language (default: python).
        system_message: Optional system-level instructions.
        model_family: Optional Copilot model family (e.g. 'gpt-4o', 'claude-sonnet-4.6').
    """
    payload: dict = {"prompt": prompt, "language": language}
    if system_message:
        payload["system_message"] = system_message
    if model_family:
        payload["model_family"] = model_family

    logger.info(f"copilot_generate: lang={language} model={model_family or 'auto'}")
    result = _bridge_request("POST", "/api/generate", payload)
    return result.get("text", "")


@mcp.tool()
def copilot_models() -> str:
    """List available GitHub Copilot models."""
    result = _bridge_request("GET", "/api/models")
    return json.dumps(result, indent=2)


@mcp.tool()
def copilot_status() -> str:
    """Check the connection status of the Copilot Bridge and Ollama."""
    result = _bridge_request("GET", "/api/status")
    return json.dumps(result, indent=2)


# ═══════════════════════════════════════════════════════════════════════════
#  OLLAMA TOOLS
# ═══════════════════════════════════════════════════════════════════════════

@mcp.tool()
def ollama_generate(
    prompt: str,
    model: str = "",
    language: str = "python",
    system_message: str = ""
) -> str:
    """
    Generate code or text using a local Ollama model via the VS Code bridge.

    Args:
        prompt: The generation prompt or coding task description.
        model: Ollama model name (default: qwen3-coder-128k:latest).
        language: Target programming language (default: python).
        system_message: Optional system-level instructions.
    """
    config = _load_config()
    ollama_model = model or config.get("routing", {}).get("default_ollama_model", "qwen3-coder-128k:latest")

    payload: dict = {"prompt": prompt, "model": ollama_model, "language": language}
    if system_message:
        payload["system_message"] = system_message

    logger.info(f"ollama_generate: model={ollama_model} lang={language}")
    result = _bridge_request("POST", "/api/ollama/generate", payload, timeout=300)
    return result.get("text", "")


@mcp.tool()
def ollama_models() -> str:
    """List locally available Ollama models."""
    result = _bridge_request("GET", "/api/ollama/models")
    return json.dumps(result, indent=2)


# ═══════════════════════════════════════════════════════════════════════════
#  SMART ROUTING
# ═══════════════════════════════════════════════════════════════════════════

@mcp.tool()
def smart_generate(
    prompt: str,
    language: str = "python",
    system_message: str = "",
    model_preference: str = "auto"
) -> str:
    """
    Intelligently route generation between Copilot and local Ollama models.

    Routing logic:
      - "auto" (default): Small tasks (≤32k tokens) go to Ollama to save
        credits. Large tasks go to Copilot. If Copilot is out of tokens,
        automatically falls back to Ollama.
      - "copilot": Force Copilot.
      - "ollama": Force local Ollama.

    Args:
        prompt: The generation prompt or coding task description.
        language: Target programming language (default: python).
        system_message: Optional system-level instructions.
        model_preference: Routing preference: "auto", "copilot", or "ollama".
    """
    config = _load_config()
    routing = config.get("routing", {})
    threshold = routing.get("small_task_token_threshold", 32000)
    default_ollama = routing.get("default_ollama_model", "qwen3-coder-128k:latest")
    enable_fallback = routing.get("enable_exhaustion_fallback", True)

    # ── Explicit routing ────────────────────────────────────────────────
    if model_preference == "ollama":
        logger.info("smart_generate: explicit ollama routing")
        return _do_ollama(prompt, language, system_message, default_ollama)

    if model_preference == "copilot":
        logger.info("smart_generate: explicit copilot routing")
        return _do_copilot(prompt, language, system_message)

    # ── Auto routing ────────────────────────────────────────────────────
    full_text = prompt + (system_message or "")
    estimated_tokens = _estimate_tokens(full_text)
    logger.info(f"smart_generate: auto routing, estimated_tokens={estimated_tokens}, threshold={threshold}")

    if estimated_tokens <= threshold:
        # Small task → try Ollama first
        logger.info("smart_generate: small task → Ollama first")
        try:
            return _do_ollama(prompt, language, system_message, default_ollama)
        except Exception as e:
            logger.warning(f"smart_generate: Ollama failed ({e}), falling back to Copilot")
            return _do_copilot(prompt, language, system_message)
    else:
        # Large task → try Copilot first
        logger.info("smart_generate: large task → Copilot first")
        try:
            return _do_copilot(prompt, language, system_message)
        except Exception as e:
            error_msg = str(e)
            if enable_fallback and _is_token_exhaustion(error_msg):
                logger.warning(f"smart_generate: Copilot exhausted ({e}), falling back to Ollama")
                return _do_ollama(prompt, language, system_message, default_ollama)
            raise


def _do_copilot(prompt: str, language: str, system_message: str) -> str:
    """Execute a Copilot generation request."""
    payload: dict = {"prompt": prompt, "language": language}
    if system_message:
        payload["system_message"] = system_message
    result = _bridge_request("POST", "/api/generate", payload)
    provider = result.get("provider", "copilot")
    model_info = result.get("model", {})
    logger.info(f"[{provider}] Response from {model_info.get('name', 'unknown')}")
    return result.get("text", "")


def _do_ollama(prompt: str, language: str, system_message: str, model: str) -> str:
    """Execute an Ollama generation request."""
    payload: dict = {"prompt": prompt, "model": model, "language": language}
    if system_message:
        payload["system_message"] = system_message
    result = _bridge_request("POST", "/api/ollama/generate", payload, timeout=300)
    logger.info(f"[ollama] Response from {model}")
    return result.get("text", "")


# ── Entry Point ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    logger.info("Starting Copilot Bridge MCP server v2 (stdio transport)...")
    mcp.run(transport="stdio")
