from google.antigravity import Agent, LocalAgentConfig
import asyncio

async def main():
    async with Agent(LocalAgentConfig()) as a:
        res = await a.chat('hi')
        print(await res.text())

asyncio.run(main())
