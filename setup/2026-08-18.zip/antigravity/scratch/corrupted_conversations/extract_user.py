import re
import json
import sqlite3

db_file = r"C:\Users\ansac\.gemini\antigravity\scratch\corrupted_conversations\5bd51024-fa62-4411-a648-a8f1f3feaed7.db"

try:
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute("SELECT step_payload FROM steps ORDER BY idx ASC")
    
    user_prompts = []
    
    for row in cursor:
        payload = row[0]
        if payload:
            text = payload.decode('utf-8', errors='ignore')
            # Look for typical JSON keys or text indicating USER_INPUT
            # e.g., "type":"USER_INPUT", "content":"..."
            # Since it's protobuf, it might have the text plainly
            if "USER_REQUEST" in text or "USER_INPUT" in text or "USER_EXPLICIT" in text:
                import string
                printable = set(string.printable)
                filtered = "".join(filter(lambda x: x in printable, text))
                # print the block
                user_prompts.append(filtered)

    with open(r"C:\Users\ansac\.gemini\antigravity\scratch\corrupted_conversations\user_inputs_dump.txt", "w", encoding="utf-8") as f:
        for i, p in enumerate(user_prompts):
            f.write(f"\n\n--- USER INPUT {i} ---\n")
            f.write(p[-2000:]) # Just write the text to see if it's there
            
except Exception as e:
    print(f"Error: {e}")
