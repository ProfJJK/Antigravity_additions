import sqlite3
import string
import re

db_file = r"C:\Users\ansac\.gemini\antigravity\scratch\corrupted_conversations\5bd51024-fa62-4411-a648-a8f1f3feaed7.db"
printable = set(string.printable)

try:
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute("SELECT idx, step_payload FROM steps ORDER BY idx ASC")
    
    responses = []
    
    for row in cursor:
        idx, payload = row
        if payload:
            text = payload.decode('utf-8', errors='ignore')
            filtered = "".join(filter(lambda x: x in printable, text))
            words = re.findall(r'[a-zA-Z0-9\s.,?!;:_()\[\]{}"\'-]{20,}', filtered)
            if words:
                combined = " ".join(words).strip()
                if "EPHEMERAL_MESSAGE" not in combined and "CRITICAL INSTRUCTION" not in combined and "system prompt" not in combined.lower():
                    # Filter out purely tool-like JSON and generic instructions to get conversational responses
                    if len(combined) > 20:
                        responses.append(combined)

    print("=== INITIAL USER REQUEST ===")
    if responses:
        print(responses[0][:500])
    
    print("\n=== FINAL EXTRACTED TEXT ===")
    # Print the last 5 significant blocks
    for r in responses[-5:]:
        print("---")
        print(r[-1000:])
        
except Exception as e:
    print(f"Error reading DB: {e}")
