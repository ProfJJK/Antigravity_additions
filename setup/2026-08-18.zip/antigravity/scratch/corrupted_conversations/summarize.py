import re

extracted_file = r"C:\Users\ansac\.gemini\antigravity\scratch\corrupted_conversations\extracted_text.txt"

with open(extracted_file, 'r', encoding='utf-8') as f:
    blocks = f.read().split("--- BLOB ")

user_requests = []
results = []

for block in blocks:
    if "USER_INPUT" in block or "USER_REQUEST" in block or "USER_EXPLICIT" in block:
        user_requests.append(block)
    if "final" in block.lower() and "result" in block.lower() or "PLANNER_RESPONSE" in block:
        results.append(block)

print(f"Found {len(user_requests)} user requests and {len(results)} possible results.")

# Let's save the most relevant parts to a summary file
summary_file = r"C:\Users\ansac\.gemini\antigravity\scratch\corrupted_conversations\summary.txt"
with open(summary_file, 'w', encoding='utf-8') as f:
    f.write("=== INITIAL USER REQUEST ===\n")
    if user_requests:
        f.write(user_requests[0][:2000] + "\n\n")
    f.write("=== FINAL RESULTS ===\n")
    if results:
        f.write(results[-1][:2000] + "\n")
