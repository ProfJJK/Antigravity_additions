import sqlite3
import string

db_file = r"C:\Users\ansac\.gemini\antigravity\scratch\corrupted_conversations\5bd51024-fa62-4411-a648-a8f1f3feaed7.db"
printable = set(string.printable)

try:
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute("SELECT idx, step_payload FROM steps ORDER BY idx ASC")
    
    first_step = None
    last_step = None
    
    for row in cursor:
        idx, payload = row
        if payload:
            text = payload.decode('utf-8', errors='ignore')
            filtered = "".join(filter(lambda x: x in printable, text))
            
            # Simple heuristic to find human-readable text blocks
            # We look for continuous blocks of characters
            import re
            words = re.findall(r'[a-zA-Z0-9\s.,?!;:_()\[\]{}"\'-]{20,}', filtered)
            
            if words:
                combined = " ".join(words).strip()
                if not first_step and len(combined) > 20:
                    first_step = (idx, combined)
                if len(combined) > 20:
                    last_step = (idx, combined)

    print("=== FIRST INSTRUCTION BLOCK ===")
    if first_step:
        print(f"Step {first_step[0]}:\n{first_step[1][:1000]}")
    else:
        print("None found")
        
    print("\n=== FINAL RESULTS/LAST BLOCK ===")
    if last_step:
        print(f"Step {last_step[0]}:\n{last_step[1][-1000:]}")
    else:
        print("None found")

except Exception as e:
    print(f"Error reading DB: {e}")
