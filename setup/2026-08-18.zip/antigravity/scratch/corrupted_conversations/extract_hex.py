import re
import binascii
import string

dump_file = r"C:\Users\ansac\.gemini\antigravity\scratch\corrupted_conversations\dump.sql"
output_file = r"C:\Users\ansac\.gemini\antigravity\scratch\corrupted_conversations\extracted_text.txt"

printable = set(string.printable)

with open(dump_file, 'r', encoding='utf-8', errors='ignore') as f:
    content = f.read()

blobs = re.findall(r"X'([0-9A-Fa-f]+)'", content)

with open(output_file, 'w', encoding='utf-8') as out:
    for i, blob in enumerate(blobs):
        try:
            data = binascii.unhexlify(blob)
            text = data.decode('utf-8', errors='replace')
            filtered_text = "".join(filter(lambda x: x in printable, text))
            if len(filtered_text) > 50:
                out.write(f"--- BLOB {i} ---\n")
                out.write(filtered_text + "\n\n")
        except Exception:
            pass
