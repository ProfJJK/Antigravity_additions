import re

dump_file = r"C:\Users\ansac\.gemini\antigravity\scratch\corrupted_conversations\dump.sql"
output_file = r"C:\Users\ansac\.gemini\antigravity\scratch\corrupted_conversations\extracted_user_input.txt"

with open(dump_file, 'r', encoding='utf-8', errors='ignore') as f, open(output_file, 'w', encoding='utf-8') as out:
    for line in f:
        if "USER_INPUT" in line or "USER_EXPLICIT" in line or "PLANNER_RESPONSE" in line or "assistant" in line:
            # Let's just grab lines that look like INSERT INTO steps...
            if line.startswith("INSERT INTO"):
                out.write(line)
