from google.antigravity import Agent, AgentConfig
import asyncio

async def main():
    async with Agent(AgentConfig()) as a:
        res = await a.chat('hi')
        print(await res.text())

asyncio.run(main())
