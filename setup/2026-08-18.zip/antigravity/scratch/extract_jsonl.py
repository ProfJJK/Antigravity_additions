import json
import os

transcript_path = r"C:\Users\ansac\.gemini\antigravity\brain\c390a1ad-cf5e-47e0-98a2-b033ad7417a0\.system_generated\logs\transcript_full.jsonl"
output_path = r"C:\Users\ansac\.gemini\antigravity\scratch\user_prompts.json"

prompts = []

try:
    if os.path.exists(transcript_path):
        with open(transcript_path, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    step = json.loads(line)
                    if step.get('type') == 'USER_INPUT':
                        content = step.get('content', '')
                        if content:
                            prompts.append(content)
                except json.JSONDecodeError:
                    pass
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(prompts, f, indent=2)

    print(f"Extracted {len(prompts)} user prompts.")
    for i, p in enumerate(prompts):
        print(f"--- Prompt {i+1} ---")
        print(p[:500])
        
except Exception as e:
    print(f"Error: {e}")
