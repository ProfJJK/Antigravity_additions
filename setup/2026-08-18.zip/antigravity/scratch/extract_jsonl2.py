import json
import os

transcript_path = r"C:\Users\ansac\.gemini\antigravity\brain\5bd51024-fa62-4411-a648-a8f1f3feaed7\.system_generated\logs\transcript_full.jsonl"

prompts = []

try:
    if os.path.exists(transcript_path):
        with open(transcript_path, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    step = json.loads(line)
                    if step.get('type') == 'USER_INPUT':
                        content = step.get('content', '')
                        if content:
                            prompts.append(content)
                except json.JSONDecodeError:
                    pass
    
    print(f"Extracted {len(prompts)} user prompts.")
    for i, p in enumerate(prompts):
        print(f"--- Prompt {i+1} ---")
        print(p.strip())
        
except Exception as e:
    print(f"Error: {e}")
