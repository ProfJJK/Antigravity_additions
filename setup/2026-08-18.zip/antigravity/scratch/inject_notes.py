import re

notes_11_1 = [
    "Think of DNA as the ultimate biological hard drive. Today we're learning about the 0s and 1s that make up our genetic code.",
    "DNA is like the master reference book locked in the library, while RNA is the photocopy you can take home.",
    "Mnemonic cue: Pure As Gold (Purines = Adenine and Guanine, 2 rings). Pyrimidines are the single rings, like a single slice of PIE.",
    "Deoxy literally means 'missing an oxygen'. It's like Ribose went on a diet and lost a single oxygen atom at the 2' spot.",
    "Poll time! Remember, one of these is the 'photocopy-only' letter.",
    "Uracil is RNA's exclusive club member. Thymine is strictly for the DNA VIP lounge.",
    "NucleoSIDE is just the base and the sugar - they are sitting 'side by side', but they don't have the energetic phosphate yet.",
    "NucleoTIDE has the Phosphate (Tide = has a 'T' sound like phosphaTe). This is the fully assembled lego brick ready for building.",
    "Notice how the names change based on the sugar and the phosphates. It's like naming a car base model vs the fully loaded trim.",
    "Quick check! What three parts make up the DNA lego brick?",
    "You need the sugar, the base, and the phosphate. Without all three, you can't build the DNA ladder.",
    "This is the super-strong glue holding the side-rails of the DNA ladder together. It's covalent, so it takes serious energy to break.",
    "Just like we read left to right, DNA machinery always reads 5' to 3'. Think of 5' as the capital letter and 3' as the period.",
    "Imagine a twisted spiral staircase. The sugar-phosphate backbone is the handrail, and the bases are the steps you walk on.",
    "How strong is the G-C bond compared to A-T? Let's see who remembers.",
    "G-C pairs have 3 hydrogen bonds. Think of them like a triple knot in your shoelaces—harder to pull apart than an A-T double knot.",
    "Antiparallel means they run in opposite directions, like a two-way street. One lane goes North, the other South.",
    "Chargaff realized that A always equals T, and G equals C. It's like pairs of shoes—if you have 10 left shoes, you must have 10 right shoes.",
    "Semiconservative means each new DNA molecule keeps one 'old' parent strand and one 'new' daughter strand. Like copying an old recipe card.",
    "Let's do some quick math with Chargaff's rules. If A is 28%, what's C?",
    "A and T take up 56% together, leaving 44% for G and C. Split that in half, and you get 22% Cytosine.",
    "Can you be the DNA polymerase? Match the complement to this strand.",
    "Remember to reverse the direction. The complement is made 5' to 3', but anti-parallel to the original!"
]

notes_11_2 = [
    "Welcome back! Now we'll see how the DNA hard drive actually runs programs to make proteins.",
    "mRNA is the messenger pigeon, rRNA is the factory, and tRNA is the delivery truck.",
    "Transcription is like a scribe copying a recipe from an ancient book into a modern language.",
    "Before the mRNA leaves the nucleus, it gets a protective cap and tail, like putting on a hat and shoes before going outside.",
    "Poll time! Can you transcribe this DNA sequence?",
    "Remember to swap out Thymine for Uracil. The RNA transcript is the antiparallel photocopy.",
    "tRNA is like an Uber driver. The anticodon is the license plate matching the mRNA's pickup request.",
    "The genetic code is read in words of three letters. AUG is the green light to start driving.",
    "Translation is an assembly line. The ribosome slides along, adding amino acids one by one.",
    "Quick check! What's the green light codon?",
    "AUG is universal. It always brings Methionine to the start of the protein.",
    "Mutations are like typos. Some don't matter (silent), some change a word (missense), and some stop the sentence early (nonsense).",
    "Viruses are the ultimate biological hackers. They break in and steal the cell's machinery to print more hackers.",
    "Retroviruses like HIV do things backward. They turn RNA back into DNA, like reverse-engineering a cake into a recipe.",
    "What happens when you add an extra letter to a word?",
    "A frameshift is like shifting all your fingers on a keyboard by one key. Suddenly 'HELLO' becomes 'JRKKP'.",
    "Restriction enzymes are molecular scissors. They look for specific palindromes to make their cuts.",
    "Plasmids are like USB flash drives for bacteria. We can load them with human genes to make them do work for us.",
    "PCR is a molecular photocopier. You heat it up to split the DNA, then enzymes build copies. Billions of copies in an hour!",
    "Poll time! What do restriction enzymes do?",
    "They are molecular scissors that cut at very specific palindromic sequences.",
    "Thanks to recombinant technology, we don't have to harvest insulin from pigs anymore. Bacteria do it for us, safely and cheaply.",
    "Here's the summary of the Central Dogma. DNA makes RNA makes protein.",
    "Poll time! Which enzyme reverses the flow of information?",
    "Reverse transcriptase. It's the ultimate 'uno reverse' card for retroviruses."
]

notes_12_1 = [
    "Welcome to Chapter 12. Today we're looking at how the food you eat turns into the energy that powers you.",
    "Catabolism breaks things down to release energy (like burning wood). Anabolism builds things up (like building a house).",
    "Digestion is stage 1. Degradation is stage 2. ATP production is the grand finale in stage 3.",
    "ATP is the cell's rechargeable battery. When it snaps off a phosphate, it releases energy to do work.",
    "Poll time! How much energy is stored in that ATP battery?",
    "Negative 7.3 kilocalories per mole! That's the exergonic burst of energy that keeps your cells alive.",
    "NAD+ is like an empty dump truck. It picks up electrons and becomes NADH (a full dump truck).",
    "FAD is another kind of dump truck. It picks up two hydrogens to become FADH2.",
    "Coenzyme A is a carrier molecule. It grabs acetyl groups and hauls them into the Citric Acid Cycle.",
    "Poll time! What happens to NAD+ during an oxidation reaction?",
    "It gets reduced! Remember, if the substrate is oxidized (loses electrons), the coenzyme must be reduced (gains them).",
    "Carb digestion starts in your mouth with saliva. Chew a cracker long enough, and it starts to taste sweet!",
    "Lipids are emulsified by bile (like dish soap breaking up grease). Proteins are chopped by stomach acid and pepsin.",
    "Summary time! Carbs break into sugars, lipids into fatty acids, and proteins into amino acids.",
    "Poll time! Which sugar is the main event for our cells?",
    "D-Glucose. It's the primary fuel for your brain and red blood cells.",
    "Glycolysis means 'sugar splitting'. It happens in the cytosol and breaks 6-carbon glucose into two 3-carbon pyruvates.",
    "Phase 1 requires you to spend 2 ATP. It's like paying a toll to get onto the energy highway.",
    "Phase 2 is the payoff. You get 4 ATP and 2 full NADH dump trucks out of it.",
    "Poll time! What is your net profit from glycolysis?",
    "Net gain is 2 ATP and 2 NADH. You made 4, but had to pay back the 2 you spent at the start.",
    "Here's the complete balanced equation. Everything is accounted for.",
    "Poll time! Where does all this sugar splitting happen?",
    "In the cytosol. No mitochondria or oxygen needed yet!"
]

notes_12_2 = [
    "Welcome back. Now we find out what happens to pyruvate after glycolysis.",
    "If you have oxygen, pyruvate goes to the mitochondria for the VIP treatment. If no oxygen, it gets fermented.",
    "When you sprint and run out of oxygen, your muscles make lactate. That's why they burn!",
    "Lactate fermentation is a desperate measure to keep glycolysis running by emptying the NADH dump trucks.",
    "Poll time! Why do your muscles make lactate?",
    "To regenerate NAD+. Without it, glycolysis stops and you get no ATP.",
    "The Citric Acid Cycle is the central hub of metabolism. It's an 8-step merry-go-round in the mitochondria.",
    "For every turn of the cycle, we load up 3 NADH trucks, 1 FADH2 truck, and make 1 ATP.",
    "Since one glucose makes two pyruvates, the merry-go-round turns twice per glucose molecule.",
    "Poll time! How many dump trucks get filled on one turn of the cycle?",
    "Three NADH and one FADH2. They are now heading to the electron transport chain.",
    "The mitochondria is the powerhouse of the cell. It has two membranes, creating a space to pump protons into.",
    "The Electron Transport Chain is a series of pumps. NADH and FADH2 drop off their electrons, which power the pumping of protons.",
    "ATP Synthase is a literal microscopic turbine. Protons flow through it, spinning it to crank out ATP.",
    "Poll time! Who catches the electrons at the very end of the chain?",
    "Oxygen! That's the entire reason you are breathing right now. It catches electrons and becomes water.",
    "The final tally: 1 glucose gives us 30 to 32 ATP. The mitochondria is incredibly efficient.",
    "Compare this to glycolysis alone (2 ATP). Aerobic respiration is like a modern power plant compared to a campfire.",
    "Poll time! How much ATP do we get from completely burning one glucose?",
    "30 to 32 ATP. Almost 15 times more than anaerobic glycolysis alone!",
    "Beta-oxidation chops up long fatty acids two carbons at a time. A single fat molecule can yield over 100 ATP!",
    "When you run out of carbs and fat, you can burn protein. Aminotransferases strip the nitrogen off amino acids.",
    "The body can't keep ammonia around because it's toxic. The liver turns it into urea so you can safely pee it out.",
    "Poll time! Which organ is responsible for detoxifying ammonia into urea?",
    "The liver! It's the master chemical processing plant of your body."
]

def process_file(path, notes):
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Handle line endings
    content = content.replace('\r\n', '\n')
    slides = re.split(r'\n---\n', content)
    
    new_slides = []
    note_idx = 0
    for i, slide in enumerate(slides):
        # The very first slide (frontmatter) often contains marp: true
        if not slide.strip() or 'marp: true' in slide:
            new_slides.append(slide)
            continue
            
        if note_idx < len(notes):
            note = f"<!-- speaker_note: {notes[note_idx]} -->"
            slide = slide.rstrip() + "\n\n" + note + "\n"
            note_idx += 1
            
        new_slides.append(slide)
        
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n---\n'.join(new_slides))
    print(f"Processed {path}. Used {note_idx}/{len(notes)} notes.")

process_file('D:/Gdrive/_CU Teaching/2026SP CHEM103 Fundamentals of Chemistry/26FA103_PPTs/26FA103_11-first_half.md', notes_11_1)
process_file('D:/Gdrive/_CU Teaching/2026SP CHEM103 Fundamentals of Chemistry/26FA103_PPTs/26FA103_11-second_half.md', notes_11_2)
process_file('D:/Gdrive/_CU Teaching/2026SP CHEM103 Fundamentals of Chemistry/26FA103_PPTs/26FA103_12-first_half.md', notes_12_1)
process_file('D:/Gdrive/_CU Teaching/2026SP CHEM103 Fundamentals of Chemistry/26FA103_PPTs/26FA103_12-second_half.md', notes_12_2)
