from google.antigravity import Agent, LiteRTAgentConfig, LocalOpenAIAgentConfig
import asyncio

async def main():
    print("Testing LiteRTAgentConfig")
    try:
        async with Agent(LiteRTAgentConfig()) as a:
            res = await a.chat('hi')
            print(await res.text())
    except Exception as e:
        print("LiteRT failed:", e)
        
    print("Testing LocalOpenAIAgentConfig")
    try:
        async with Agent(LocalOpenAIAgentConfig(base_url="http://localhost:11434/v1", model="llama3")) as a:
            res = await a.chat('hi')
            print(await res.text())
    except Exception as e:
        print("LocalOpenAI failed:", e)

asyncio.run(main())
