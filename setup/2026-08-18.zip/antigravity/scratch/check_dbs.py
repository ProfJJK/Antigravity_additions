import sqlite3
import os
import glob

folder = r"C:\Users\ansac\.gemini\antigravity\conversations"
db_files = glob.glob(os.path.join(folder, "*.db"))

corrupt_dbs = []
for db in db_files:
    try:
        conn = sqlite3.connect(db)
        cursor = conn.cursor()
        cursor.execute("PRAGMA integrity_check;")
        result = cursor.fetchone()
        if result[0] != "ok":
            corrupt_dbs.append((db, result[0]))
        conn.close()
    except Exception as e:
        corrupt_dbs.append((db, str(e)))

print(f"Total DBs: {len(db_files)}")
print(f"Corrupted DBs: {len(corrupt_dbs)}")
for db, err in corrupt_dbs:
    print(db, err)
