$json = '[{"PID":123,"StartTime":"2026-08-17T12:52:11.0299886-05:00"}]'
$agents = $json | ConvertFrom-Json
$agent = $agents[0]
$procStartTime = '2026-08-17T12:52:11.0299886-05:00'
$type = $agent.StartTime.GetType().Name
$str = $agent.StartTime.ToString()
$result = ($procStartTime -eq $agent.StartTime)
Write-Output "Type: $type"
Write-Output "ToString: $str"
Write-Output "Result: $result"
