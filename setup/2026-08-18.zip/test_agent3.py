import os
os.environ['GEMINI_API_KEY'] = 'dummy_ide_key'
import asyncio
from google.antigravity import Agent, LocalAgentConfig

async def main():
    try:
        async with Agent(config=LocalAgentConfig(enable_subagents=True)) as agent:
            res = await agent.chat('say hello')
            print('SUCCESS:', res)
    except Exception as e:
        print('ERROR:', type(e).__name__, str(e))

asyncio.run(main())
