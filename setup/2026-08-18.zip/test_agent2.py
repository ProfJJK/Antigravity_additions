import os
os.environ['GEMINI_API_KEY'] = 'dummy_ide_key'
import asyncio
from google.antigravity import Agent, LocalAgentConfig

async def main():
    async with Agent(config=LocalAgentConfig(enable_subagents=True)) as agent:
        print((await agent.chat('test')).text)

asyncio.run(main())
