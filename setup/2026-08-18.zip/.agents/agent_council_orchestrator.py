import os
import sys
import asyncio
import argparse
import pathlib
import contextlib
from typing import Dict, Any, Optional

try:
    from google.antigravity import Agent, LocalAgentConfig
    import pydantic
    import dotenv
    
    # Explicitly load the global .env file to ensure API keys are found
    dotenv.load_dotenv(pathlib.Path.home() / ".env")
except ImportError:
    print("Error: The 'google-antigravity' SDK, 'pydantic', and 'python-dotenv' are required.")
    sys.exit(1)

class AuditResult(pydantic.BaseModel):
    score: float
    feedback: str

class AgentCouncilOrchestrator:
    def __init__(self, target_agent_name: str, task_description: str, max_cycles: int = 10, escape_score: float = 0.99):
        self.target_agent_name = target_agent_name
        self.task_description = task_description
        self.max_cycles = max_cycles
        self.escape_score = escape_score
        self.agents: Dict[str, Agent] = {}
        self.stack = contextlib.AsyncExitStack()
        
    async def run(self):
        async with self.stack:
            return await self._run_inner()
            
    async def _run_inner(self):
        print(f"[Orchestrator] Starting 10-Cycle Council Loop for {self.target_agent_name}")
        
        # Initial execution
        current_artifact = await self.invoke_agent(self.target_agent_name, self.task_description)
        
        for cycle in range(1, self.max_cycles + 1):
            print(f"[Orchestrator] --- Cycle {cycle}/{self.max_cycles} ---")
            
            # Step 1: Adversarial Audit
            audit_result = await self.adversarial_audit(current_artifact)
            score = audit_result.get("score", 0.0)
            print(f"[Orchestrator] Audit Score: {score * 100:.1f}%")
            
            # Step 2: Threshold Check
            if score >= self.escape_score:
                print(f"[Orchestrator] Escape score {self.escape_score*100}% reached or exceeded. Terminating loop.")
                break
                
            # Step 3: Reconvene Council to generate Fix Plan
            print("[Orchestrator] Score below threshold. Reconvening Agent Council for a fix plan...")
            fix_plan = await self.reconvene_council(audit_result, current_artifact)
            
            # Step 4: Re-Execution by original agent
            print(f"[Orchestrator] Dispatching fix plan back to {self.target_agent_name}...")
            prompt = f"The council has rejected the artifact. Please implement this Fix Plan:\n<fix_plan>\n{fix_plan}\n</fix_plan>"
            current_artifact = await self.invoke_agent(self.target_agent_name, prompt)
            
            # Step 5: (Optional for writers) Human Read Handoff
            if "scribe" in self.target_agent_name.lower():
                print(f"[Orchestrator] Passing updated artifact to human_read agent for aesthetic refinement...")
                refine_prompt = f"Refine this text to maximize human aesthetic and burstiness:\n<artifact>\n{current_artifact}\n</artifact>"
                current_artifact = await self.invoke_agent("human_read", refine_prompt)
                
        print("[Orchestrator] Council Loop Finished. Final Artifact Generated.")
        return current_artifact

    async def get_or_create_agent(self, agent_name: str) -> Agent:
        if agent_name not in self.agents:
            skills_dir = pathlib.Path.home() / ".gemini" / "config" / "skills"
            
            # Allow fallback to generic skills directory if specific one doesn't exist
            specific_skill = skills_dir / f"agent-{agent_name}"
            path_to_load = str(specific_skill) if specific_skill.exists() else str(skills_dir)
            
            kwargs = {"skills_paths": [path_to_load]}
            if agent_name == "adversary":
                kwargs["response_schema"] = AuditResult
                
            config = LocalAgentConfig(**kwargs)
            # Keep the agent alive to preserve conversation context
            agent = Agent(config)
            await self.stack.enter_async_context(agent)
            
            # Preload the context
            await agent.chat(f"You are the {agent_name} agent. Adopt this persona for all subsequent tasks.")
            self.agents[agent_name] = agent
            
        return self.agents[agent_name]

    async def invoke_agent(self, agent_name: str, prompt: str, retries: int = 3) -> str:
        print(f"  -> Invoking {agent_name}...")
        agent = await self.get_or_create_agent(agent_name)
        
        for attempt in range(retries):
            try:
                response = await agent.chat(prompt)
                return await response.text()
            except Exception as e:
                print(f"[Warning] API call failed on attempt {attempt + 1}/{retries}: {e}")
                if attempt == retries - 1:
                    return f"Error: Agent failed after {retries} attempts: {e}"
                await asyncio.sleep(2 ** attempt)
                
    async def adversarial_audit(self, artifact: str, retries: int = 3) -> Dict[str, Any]:
        print(f"  -> Invoking adversary to audit...")
        agent = await self.get_or_create_agent("adversary")
        
        prompt = f"""Please perform an adversarial audit of the following artifact. 
Ensure your score is normalized between 0.0 and 1.0 (where 1.0 is a perfect escape score).

<artifact>
{artifact}
</artifact>"""
        
        for attempt in range(retries):
            try:
                response = await agent.chat(prompt)
                data = await response.structured_output()
                if data:
                    return data
                raise ValueError("Structured output parsing failed and returned None.")
            except Exception as e:
                print(f"[Warning] API call failed on attempt {attempt + 1}/{retries}: {e}")
                if attempt == retries - 1:
                    return {"score": 0.0, "feedback": f"API call failed after {retries} attempts: {e}"}
                await asyncio.sleep(2 ** attempt)
        
        return {"score": 0.0, "feedback": "Audit failed due to API errors."}

    async def reconvene_council(self, audit_feedback: Dict[str, Any], artifact: str) -> str:
        print(f"  -> Invoking domain-expert council (cochem-improve) to plan fixes...")
        prompt = f"""The adversary audit returned a score of {audit_feedback.get('score')} with the following feedback:
<feedback>
{audit_feedback.get('feedback')}
</feedback>

Please generate a Fix Plan for this artifact based on the Method Matrix:
<artifact>
{artifact}
</artifact>"""
        return await self.invoke_agent("cochem-improve", prompt)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run the 10-Cycle Agent Council Orchestrator.")
    parser.add_argument("agent", help="The name of the target agent (e.g., cochem-scribe)")
    parser.add_argument("task", help="The task description for the target agent")
    parser.add_argument("--10-cycle-audit", dest="ten_cycle_audit", action="store_true", help="Explicitly allow running the 10-cycle audit script.")
    args = parser.parse_args()

    if not args.ten_cycle_audit and os.environ.get("COCHEM_ALLOW_10_CYCLE_AUDIT") != "1":
        import logging
        logging.error("The standalone 10-cycle audit script is deprecated.")
        logging.error("Please use native Antigravity invoke_subagent capabilities instead.")
        logging.error("To bypass this error, pass --10-cycle-audit or set COCHEM_ALLOW_10_CYCLE_AUDIT=1.")
        sys.exit(1)

    orchestrator = AgentCouncilOrchestrator(
        target_agent_name=args.agent,
        task_description=args.task,
        max_cycles=10,
        escape_score=0.99
    )
    result = asyncio.run(orchestrator.run())
    print("\n=== FINAL ARTIFACT ===\n")
    print(result)
