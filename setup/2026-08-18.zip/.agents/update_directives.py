import os

directory = r"C:\Users\ansac\.gemini\.agents"
directive = """
<ADVERSARIAL_AUDIT_DIRECTIVE>
## 10-Cycle Council Audit Mandate
1. **Mandatory Audit:** Whenever you complete a coding or writing task, you MUST NOT finalize the job. You MUST immediately invoke the `adversary` agent (or `cochem-audit`) to perform an adversarial audit of your work.
2. **Agent Council Reconvening:** If the auditor finds ANY issues, or the escape score is below 99%, the Orchestrator MUST reconvene the Agent Council to generate a fix plan.
3. **10-Cycle Iteration:** You will receive the fix plan and must generate a new iteration of the artifact. This process loops up to 10 times or until a 99% escape score is achieved.
</ADVERSARIAL_AUDIT_DIRECTIVE>
"""

for filename in os.listdir(directory):
    if filename.endswith(".agent.md"):
        filepath = os.path.join(directory, filename)
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
            
        if "enable_write_tools: true" in content and "<ADVERSARIAL_AUDIT_DIRECTIVE>" not in content:
            print(f"Adding directive to {filename}")
            with open(filepath, "a", encoding="utf-8") as f:
                f.write("\n" + directive)
        else:
            print(f"Skipping {filename}")
