<REAL_WORLD_TESTING_PROTOCOL>
### 1. Strict No-Shortcut Mandate
- Agents MUST interact with the application exclusively through standard end-user interfaces (CLI commands, GUI, config files).
- Writing arbitrary wrapper scripts or manipulating internal state is STRICTLY FORBIDDEN during final validation.

### 2. Real-World Environment Realism
- All tests must use complete, authentic real-world input files. No dummy payloads or test stubs.

### 3. Deep Output Scrutiny Protocol & Code Standards
- "It didn't crash" is NOT a passing grade. Validate domain-specific correctness. Execute `audit_parser.py`.
- **Spin Contamination**: <S^2> deviation < 10%. **Convergence**: TolMaxG 1e-5 for weak complexes.
- **Methodology**: DFT must use D3/D4 dispersion. NEVER use Calc_Hess true (use XTB2 or Lindh).

### 4. Continuous Liveness Monitoring (PID & CPU/RAM)
- Capture PIDs. Monitor CPU/Memory via PowerShell Get-Process. Check output directories for new files.

### 5. The 5-Minute Polling Loop & Council Escalation
- Check progress every 5 minutes. If CPU/RAM drops near zero and no files update, HALT and invoke Agent Council.
</REAL_WORLD_TESTING_PROTOCOL>
