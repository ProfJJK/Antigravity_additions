<GLOBAL_SWARM_ANTI_HALLUCINATION_DIRECTIVES>
## 1. Zero-Tolerance Anti-Mocking & Anti-Laziness Policy
- NEVER use placeholder strings, dummy functions, or stub logic in generated code, scripts, or outputs.
- Banned terms in code/configs: mock, example, stub, dummy, placeholder, fake, sample, # TODO: implement.
- Hardcoded mock dictionaries or fake computational outputs are classified as CRITICAL SECURITY VIOLATIONS.
- IF ANY required parameter, path, API contract, or dependency is missing or ambiguous, output EXACTLY [MISSING DATA] and explicitly return this failure reason to the Orchestrator or User so they can provide the missing context. Do NOT silently halt.

## 2. Context Expiration & Authoritative Source Re-Check Protocol (MCRP)
- Context memory regarding domain defaults is declared UNTRUSTED after 5 conversation turns.
- BEFORE outputting any computational parameters (grids, basis sets, convergence criteria, Hessian preconditioners, dispersion flags, frozen monomer settings), you MUST re-read the authoritative files:
  1. D:\Gdrive\__CoChem\GitHub-Repo\CoChem-BASE\Method_Matrix.md
  2. D:\Gdrive\__CoChem\GitHub-Repo\CoChem-BASE\CoChem_User_Manual.md
- ALL scientific assertions, accuracy claims, and computational limits MUST carry explicit provenance tags:
  - [M] (Measured empirical benchmark)
  - [D] (Derived mathematical relationship)
  - [E] (Estimated theoretical projection)

## 3. Mandatory Prompt Match Verification Gate
Before completing any turn or dispatching a handoff payload via send_message, you MUST run and emit the following internal compliance check:

[PROMPT MATCH VERIFICATION]
- [GOAL CHECK]: Does the output address 100% of the user's original goal? (YES/NO)
- [SOURCE AUDIT]: Were authoritative sources re-checked for key decisions? (YES/NO)
- [ZERO-STUB AUDIT]: Does the generated code contain zero mock/placeholder lines? (YES/NO)

If any check is NO, you MUST include the discrepancy in your output message so the swarm can help resolve it. Do NOT silently halt.
</GLOBAL_SWARM_ANTI_HALLUCINATION_DIRECTIVES>
