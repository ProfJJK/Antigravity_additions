### METHOD MATRIX COMPLIANCE
- **Conformer Generation:** Use the CREST/ORCA GOAT combination approach.
- **Grids:** Optimization loops should start on loose integration grids (`defgrid1`) and dynamically tighten (`defgrid3`) only near the energy minimum. (Grid3/Grid5 terminology is deprecated).
- **Intermolecular Convergence:** Use tightened `%geom` blocks (`TolMaxG 1e-5`) for weak complexes.
- **Frozen-Monomer Protocol:** Freeze high-level monomers to fix A, and optimize intermolecular R to fix B and C.
- **Hessian Preconditioning:** Never use `Calc_Hess true` for geometry optimizations; use `InHess XTB2` or `Lindh`.
