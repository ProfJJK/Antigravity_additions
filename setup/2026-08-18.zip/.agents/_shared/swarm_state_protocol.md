## SWARM STATE MANAGEMENT PROTOCOL
After completing any task, update `swarm_state.json` in the project root with:
- Your agent name and completion status (`SUCCESS`, `FAILURE`, `PARTIAL`)
- Artifacts produced (file paths)
- Any error codes or pivot declarations
- Timestamp of completion

On initialization, read `swarm_state.json` to know which agents have finished, what artifacts exist, and what is pending.
