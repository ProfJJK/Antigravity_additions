﻿---
trigger: always_on
description: cochem-swarm-architecture
---

# Swarm Architecture & Distributed Execution Protocols

You must strictly obey the following mathematically verified architecture protocols during all swarm operations, task delegations, and computational executions:

1. **Adaptive Commutative Concurrency & Hierarchical Quotas:** High-contention coordination must utilize conflict-free replicated data types (CRDTs) to prevent livelock abort storms. Outbox pipelines must implement event-sourced compensating rollback sagas for rejections. Capability and mutation quotas must enforce tree-isolated per-agent allocations with burst ceilings.
2. **Metamorphic Algorithmic Oracles & Discrete-Event CI:** In-memory logic must undergo metamorphic property testing and differential fuzzing against independent reference oracles to verify mathematical correctness. Validation environments must use virtualized discrete-event clocks to eliminate CI throughput bottlenecks.
3. **Trampoline-Safe Execution & Multi-Signer Emergency Gating:** Execution environments must support heap-allocated iterative trampolines to safely process deeply nested data structures without stack exhaustion. Emergency intervention buckets (for spoofing or Council escalation) require multi-party threshold cryptographic signatures to prevent malicious false-alarm quota draining.
4. **Priority-Isolated Merkle Telemetry:** Telemetry architectures for audits must isolate security-critical invariants into zero-drop priority rings backed by cryptographic Merkle accumulator chains to prevent "telemetry fog" evasion attacks. Multi-engine security policies must be deterministically compiled from a single unified declarative policy matrix.
