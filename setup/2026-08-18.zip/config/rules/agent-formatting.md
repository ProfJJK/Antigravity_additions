---
trigger: always_on
description: agent-formatting
---

# Agent File Formatting Rules

When editing `.agent.md` or `SKILL.md` files, ALWAYS use LF (Unix) line endings, never CRLF.

## Rules and Guidelines

1. **LF Line Endings Only**: Never write or edit `.agent.md` files with CRLF line endings.
2. **Swarm Troubleshooting (Loss of Tools)**: If subagents are ever unresponsive or mysteriously lose their tool capabilities, the root cause is likely CRLF line endings corrupting the YAML frontmatter. You must sweep the `config/skills` and `.agents` directories and enforce LF line endings to restore swarm functionality.
3. **Writing Files from PowerShell**: Do NOT use PowerShell's `Set-Content` to write `.agent.md` files. Use `[System.IO.File]::WriteAllText()` instead to explicitly ensure LF line endings:
   ```powershell
   [System.IO.File]::WriteAllText("$Path", $Content.Replace("`r`n", "`n"), [System.Text.Encoding]::UTF8)
   ```

## Rationale
- CRLF line endings break the YAML frontmatter parser in `.agent.md` and `SKILL.md` files, which silently removes tool access from agents, breaking the entire swarm architecture.
