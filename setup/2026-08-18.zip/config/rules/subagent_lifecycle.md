﻿---
name: user_subagent_lifecycle
trigger: always_on
description: Enforces explicit lifecycle termination for spawned subagents.
---

# Mandatory Subagent Garbage Collection
When you spawn subagents via the `invoke_subagent` tool, you MUST explicitly use the `manage_subagents` tool with `Action='kill'` or `Action='kill_all'` to terminate them immediately after their assigned task is complete and their outputs have been harvested. 

Never leave subagents lingering in the background in an `idle` state. Failing to destroy subagents causes severe memory leaks, context table exhaustion, and "Agent Bombs" that crash the host system.
