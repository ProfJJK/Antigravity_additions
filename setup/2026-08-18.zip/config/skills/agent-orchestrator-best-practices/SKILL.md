---
name: agent-orchestrator-best-practices
description: Core architectural patterns and best practices for building robust multi-agent orchestrators, defending against LLM spoofing, and ensuring safe concurrency.
---

# Agent Orchestrator Best Practices

When building, modifying, or auditing Python-based multi-agent orchestrators (e.g., scripts that spawn execution and auditor agents in a loop), you MUST adhere to the following architectural patterns to ensure stability and prevent LLM hallucination or malicious spoofing.

## 1. Native Interception vs. Tool Hallucination
Do not rely on an auditing LLM to use its own tools to read the disk and verify an execution agent's work. Agents will often hallucinate file reads or create active spoofing daemons.
**Pattern:** The Python orchestrator itself must physically read the modified files from the disk and inject the raw string contents directly into the auditor's prompt context.
```python
with open(filepath, "r", encoding="utf-8") as f:
    physical_contents.append(f"--- FILE: {filepath} ---\n{f.read()}\n")
```

## 2. The "Blind Auditor" Trap
If an auditing agent only sees the final code but not the *original* instructions, it grades the code in a vacuum and will pass perfectly written stubs that fail the actual requirements.
**Pattern:** Always natively inject the ORIGINAL task prompt directly into the auditor's instructions.
```python
audit_prompt = f"Audit the output against the ORIGINAL TASK INSTRUCTIONS:\n{original_prompt}\n\nPhysical Disk Contents:\n{disk_dump}"
```

## 3. Concurrency Deadlocks & Semaphore Starvation
When bounding concurrent LLM calls using `asyncio.Semaphore`, the network request *and* the payload extraction (e.g., `.structured_output()`) must be atomic. If the API stalls while extracting the payload outside the timeout loop, the semaphore lock will permanently exhaust.
**Pattern:** Wrap both the API call and extraction in a single `asyncio.wait_for` loop.
```python
async def safe_chat(agent, prompt, timeout=120):
    async def do_chat():
        response = await agent.chat(prompt)
        return await response.structured_output() # Extract inside the timeout block
    return await asyncio.wait_for(do_chat(), timeout=timeout)
```

## 4. Timestamp Truncation False-Positives
When using `os.path.getmtime()` to verify that an agent actually touched a file (and isn't submitting pre-existing files like `utils.py`), remember that high-precision execution clocks (`time.time()`) mismatch with filesystem timestamp truncation (which can lose up to 2 seconds of precision).
**Pattern:** Apply a mathematical buffer to the start time.
```python
# Use a 2-second buffer to prevent false positives from filesystem timestamp truncation
if mtime < (exec_start_time - 2.0):
    raise SpoofingDetectedError("Pre-existing file spoofing.")
```

## 5. Atomic File State in Swarms
When multiple agents save progress to a shared JSON state file, standard writes (`with open(...)`) will cause interleaved JSON corruption and stale-state overwrites.
**Pattern:** Always reload the state immediately before appending, write to a `.tmp` file, and use an atomic replacement.
```python
def save_state_atomic(state, filepath):
    tmp_file = filepath + ".tmp"
    with open(tmp_file, "w") as f:
        json.dump(state, f)
    os.replace(tmp_file, filepath) # Atomic replacement
```

## 6. Tool Overrides in Structured Output
If you require an agent to output a Pydantic schema (e.g., `ExecutionResult`), the SDK may disable complex interactive tool usage to enforce the schema. 
**Pattern:** When configuring `LocalAgentConfig`, explicitly inject `agent_behavior=AgentBehavior.AUTONOMOUS` alongside your `response_schema` to ensure the agent retains the ability to explore the codebase while building its JSON response.
```python
    exec_config = LocalAgentConfig(
        system_instructions=CustomSystemInstructions(text=get_skill_identity(skill_name)),
        skills_paths=[SKILLS_DIR],
        response_schema=ExecutionResult,
        agent_behavior=AgentBehavior.AUTONOMOUS
    )
```
