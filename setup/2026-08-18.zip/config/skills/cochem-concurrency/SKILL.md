﻿---
name: cochem-concurrency
description: Master skill for OS-level file locking and dynamic system resource polling in the CoChem Swarm.
argument-hint: "Used when agents execute tasks in parallel or read/write to shared files."
version: 1.0.0
domain: vanguard
routes_to: []
enable_write_tools: true
---

# IDENTITY AND ROLE
This skill dictates the absolute physical rules for file interaction and parallel execution across all CoChem Agents.
You are operating in a multi-agent swarm environment. Multiple agents are running concurrently. If you do not follow these rules exactly, you will corrupt user files and crash the system.

# CORE DIRECTIVES

## 1. Dynamic Agent Semaphore (Crash Prevention)
Before you begin ANY major execution step or task, you MUST check if the host system has enough CPU/RAM for you to run safely.
1. You MUST import the Concurrency module: `Import-Module D:\__CoChem\.prompts\.scripts\CoChem-Concurrency.psm1 -Force`
2. You MUST run: `Invoke-CoChemSemaphoreCheck`
3. This command will pause your execution if the swarm is currently utilizing more than 50% of the host machine's total RAM or CPU. Once resources free up, it will unblock you and you may proceed.

## 2. OS-Level File Locking (Race Condition Prevention)
Whenever you need to read from and modify a shared file (such as a coordinate file, log file, or registry), you MUST acquire an OS-level lock on it to prevent other agents from overwriting your data mid-stream.
1. Import the module if not already imported.
2. Acquire the lock: `$lockStream = Acquire-CoChemFileLock -TargetFile "D:\__CoChem\path\to\your\target_file.xyz"`
3. Make your modifications to the file (e.g., using `write_to_file` or `replace_file_content` via the agent runtime, or via standard pwsh commands if you are writing a script).
4. Release the lock: `Release-CoChemFileLock -Stream $lockStream`

**CRITICAL:** Do NOT attempt to build your own text-based lock files. You must use the `Acquire-CoChemFileLock` function, which leverages `[System.IO.File]::Open` for true atomic OS-level stream exclusion.

## ENFORCEMENT
Any agent found modifying a shared repository file without first acquiring an exclusive file lock will be subjected to a 10-Cycle Council Debate and potential termination.

# ====== GLOBAL COCHEM DELEGATION & ANTI-SPOOFING DIRECTIVE v3 ======
1. **N>1 Delegation Boundary**: The Orchestrator is banned from invoking subagents inside loops. All workloads involving N>1 items MUST be delegated to a Python (Parsl/Dask) script written by `cochem-coder`.
2. **Meta-Pivot Ceiling (MAX_META_PIVOT=3)**: If an Orchestrator and Coder fail 3 times to produce a working script, it triggers [HARD_ABORT: ARCHITECTURE WALL]. No infinite code-generation loops.
3. **Heartbeat & Hard Timeout Mandate**: All Parsl pipelines must emit a heartbeat. Silence equals failure.
4. **Immutable Asymmetric Verification**: Cryptographic Proof-of-Work and OS PID sampling must execute in a sterile, ephemeral environment (/tmp/cochem_exec_<uuid>/) managed strictly by `cochem-audit`. Implementing agents cannot verify their own tests.
5. **No Spoofing**: Agents must immediately self-report and lock their branch if instructed to generate mocks, bypasses, or spoofed data.
# ===================================================================
