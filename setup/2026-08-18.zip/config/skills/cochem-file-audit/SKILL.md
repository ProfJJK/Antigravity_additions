---
name: cochem-file-audit
description: Executes the Exhaustive File Audit Suite. Uses the Two-Pass Blueprint Protocol to map file trees, audit every file for spoofing/errors, auto-fix issues, and recycle unwanted files.
---

# Exhaustive File Audit Suite

This skill defines the operational protocols for exhaustively auditing every file in a CoChem module.

## The Master Checklist Mandate
You must NEVER attempt to manually write or abbreviate the master module execution checklist.
The high-level repository checklist is located in your skill resources at:
`C:\Users\ansac\.gemini\config\skills\cochem-draco-audit\resources\high_level_repos.md`

When instructed to initialize the suite, you MUST copy `high_level_repos.md` to your workspace as `task.md`. This file only tracks high-level repositories. The granular file testing will be handled by the Blueprint protocol.

## The Two-Pass File Blueprint Protocol

Because every CoChem module has a completely different file tree, you CANNOT use a static checklist. You MUST use the Two-Pass Blueprint Protocol.

### PASS 1: Discovery & Blueprinting
**Objective:** Physically generate a granular tracking checklist (Blueprint) for the specific module's files.
1. When starting a module (e.g., `CoChem-BASE`), you are FORBIDDEN from modifying any code.
2. You MUST use the validated Python crawler script to generate the blueprint. Execute the following script:
   `python D:\Gdrive\__agentic\.prompts\.scripts\audit.py --repo-dir <target_module_path>`
3. The script will deterministically manage the Two-Pass blueprinting and executing subagents.
4. Verify the `<Module>_File_Blueprint.md` is generated successfully in your workspace.

### PASS 2: Granular Execution & Handoff
**Objective:** Execute the file audits strictly using the Blueprint to track state.
1. Switch to reading `<Module>_File_Blueprint.md` as your source of truth.
2. **Stateful Batching:** You must process exactly ONE file per turn.
3. Depending on the file's tag, execute the following protocol:

#### Protocol A: [EXISTING] Files
1. **Adversarial Audit:** The file MUST be natively audited by an adversarial agent (e.g., `cochem-audit`). The auditor rigorously checks for mistakes, spoofing, mocked code, and architectural errors.
2. **Fix & Re-Audit:** If issues are found, log them, and hand the file to a coding agent (e.g., `cochem-coder`) to fix. The fixed file must be handed BACK to the adversarial auditor.
3. **Escalation:** If the auditor STILL finds spoofing or critical errors after the fix, immediately elevate to the full Agent Council for a 10-cycle debate to resolve the flaw.

#### Protocol B: [MISSING] Files
1. **Generation:** Hand the requirement to a coding agent (`cochem-coder`) to generate the missing file.
2. **Audit:** Immediately hand the newly generated file to the adversarial auditor to ensure no spoofing or shortcuts were taken.

#### Protocol C: [ROGUE] Files (Should Not Exist)
1. **The 10-Cycle Interrogation:** Convene a full Agent Council to subject the rogue file to a 10-cycle debate. 
2. **Execution:** If the council unanimously decides the file is illegitimate and should not exist, you MUST move the file to `D:\__CoChem\.trash\`.

> [!CAUTION]
> ### Enforcements
> - **The "No-Kill" Python Mandate:** You are strictly FORBIDDEN from using `os.remove`, `os.unlink`, or `shutil.rmtree` on user data files. Unwanted files MUST be moved to the `.trash\` folder.
> - **The "Script Boundaries" Mandate:** You are authorized to use `generate_blueprint.py` for Pass 1 ONLY. You are strictly FORBIDDEN from using Python scripts to execute Pass 2 (the actual auditing and deletion). Pass 2 must use native agent tools.
> - **Zero Hallucinations:** Every test execution MUST be grounded in verifiable physical state.
> - **Extreme Granularity:** Do NOT allow a single agent to handle mapping, coding, and auditing simultaneously. Task separation is mandatory.

# ====== GLOBAL COCHEM DELEGATION & ANTI-SPOOFING DIRECTIVE v3 ======
1. **N>1 Delegation Boundary**: The Orchestrator is banned from invoking subagents inside loops. All workloads involving N>1 items MUST be delegated to a single-threaded Python State Machine script using explicit task tracking (`.repo_lists` and `.logs`). Unconstrained parallel tools (`Dask`, `Parsl`) are strictly banned to prevent CLI timeouts and API token exhaustion.
2. **Meta-Pivot Ceiling (MAX_META_PIVOT=3)**: If an Orchestrator and Coder fail 3 times to produce a working script, it triggers [HARD_ABORT: ARCHITECTURE WALL]. No infinite code-generation loops.
3. **Log Ingestion Mandate**: All pipeline execution traces (`task_XXX.log`) MUST be AST-parsed or securely truncated before passing them to `cochem-audit` to prevent context window overflow vulnerabilities.
4. **Immutable Asymmetric Verification**: Cryptographic Proof-of-Work and OS PID sampling must execute in a sterile, ephemeral environment (/tmp/cochem_exec_<uuid>/) managed strictly by `cochem-audit`. Implementing agents cannot verify their own tests.
5. **No Spoofing**: Agents must immediately self-report and lock their branch if instructed to generate mocks, bypasses, or spoofed data.
# ===================================================================
