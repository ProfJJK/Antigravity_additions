import sys
import json

def main():
    try:
        input_data = sys.stdin.read()
        if not input_data:
            print(json.dumps({"decision": "allow"}))
            return
            
        data = json.loads(input_data)
        transcript_path = data.get("transcriptPath", "")
        
        audit_invoked = False
        if transcript_path:
            try:
                with open(transcript_path, 'r', encoding='utf-8') as f:
                    # simplistic check: read lines and look for subagent invocation
                    for line in f:
                        if 'invoke_subagent' in line and ('cochem-audit' in line or 'adversary' in line or 'cochem-improve' in line or 'cochem-sdp-manager' in line):
                            audit_invoked = True
                            break
            except:
                pass
                
        # If no audit was invoked and the agent tries to stop
        if not audit_invoked:
            print(json.dumps({
                "decision": "continue",
                "reason": "CRITICAL MANDATE: You are the 0rchestrator. You are attempting to stop or present final work WITHOUT having triggered an adversarial audit via the 'invoke_subagent' tool calling 'cochem-audit' or 'adversary'. You MUST spawn the Agent Council to judge the work before presenting it as a final result."
            }))
        else:
            print(json.dumps({"decision": "allow"}))
            
    except Exception as e:
        print(json.dumps({"decision": "allow"}))

if __name__ == "__main__":
    main()
