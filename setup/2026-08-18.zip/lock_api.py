import os
scripts = [r'D:\Gdrive\__agentic\.prompts\.scripts\test.py', r'D:\Gdrive\__agentic\.prompts\.scripts\audit.py', r'D:\Gdrive\__agentic\.prompts\.scripts\improv.py']
replacement = '# ==============================================================================\n# CRITICAL ANTI-SPOOFING & API PROXY DIRECTIVE (DO NOT MODIFY)\n# The google.antigravity standalone Python SDK crashes if GEMINI_API_KEY is empty.\n# However, we MUST NOT use a real external Gemini API key.\n# By setting this to \
dummy_ide_key\, the Antigravity IDE daemon intercepts the\n# request and routes it to the native, unlimited quota local backend.\n# DO NOT CHANGE THIS TO CORE_API_KEY OR ANY OTHER VALUE.\n# ==============================================================================\nos.environ.pop(\GEMINI_API_KEY\, None)\nos.environ[\GEMINI_API_KEY\] = \dummy_ide_key\\n'
for script in scripts:
    with open(script, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    cleaned_lines = []
    for line in lines:
        if 'GEMINI_API_KEY' not in line and 'CORE_API_KEY' not in line and 'PURGE API KEY' not in line:
            cleaned_lines.append(line)
    insert_idx = 0
    for i, line in enumerate(cleaned_lines):
        if line.startswith('import ') or line.startswith('from '):
            insert_idx = i + 1
    cleaned_lines.insert(insert_idx, '\n' + replacement + '\n')
    with open(script, 'w', encoding='utf-8') as f:
        f.writelines(cleaned_lines)
    print(f'Locked {os.path.basename(script)}')
