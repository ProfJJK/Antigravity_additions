import os
import json
import glob

repo = r'D:\__CoChem\GitHub-Repo'

modules = sorted([d for d in os.listdir(repo) if os.path.isdir(os.path.join(repo, d)) and not d.startswith('.') and not d.startswith('__') and d not in ['node_modules', 'artifacts', 'Report_Archive', 'generated_figures', 'submissions', 'HPC_Payloads']])

report = []
report.append(f"TOTAL MODULES SCANNED: {len(modules)}")

for m in modules:
    mp = os.path.join(repo, m)
    nbs = [os.path.relpath(f, repo) for f in glob.glob(os.path.join(mp, '**', '*.ipynb'), recursive=True) if '.venv' not in f and 'site-packages' not in f and '.trash' not in f]
    py_files = [os.path.relpath(f, repo) for f in glob.glob(os.path.join(mp, '**', '*.py'), recursive=True) if '.venv' not in f and 'site-packages' not in f]
    test_files = [f for f in py_files if 'test' in f.lower()]
    core_files = [f for f in py_files if 'test' not in f.lower()]
    
    # Check for web UI or CLI apps
    web_files = [f for f in py_files if 'web' in f.lower() or 'gui' in f.lower() or 'app' in f.lower() or 'server' in f.lower()]
    
    report.append(f"\n========================================================")
    report.append(f"MODULE: {m}")
    report.append(f"Notebooks ({len(nbs)}): {nbs}")
    report.append(f"Test Suites ({len(test_files)}): {test_files}")
    report.append(f"Web/GUI/Server files ({len(web_files)}): {web_files}")
    report.append(f"Core Python files ({len(core_files)}): {core_files}")

out_path = r'C:\Users\ansac\.gemini\antigravity-cli\scratch\modules_inventory.txt'
with open(out_path, 'w', encoding='utf-8') as f:
    f.write('\n'.join(report))

print(f"Inventory saved to {out_path}")
