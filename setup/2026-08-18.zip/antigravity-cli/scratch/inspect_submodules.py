import os
import glob

repo = r'D:\__CoChem\GitHub-Repo'

modules_to_inspect = ['CoChem-CATALYST', 'CoChem-LUMOS', 'CoChem-MAGE', 'CoChem-NODE', 'CoChem-ORACLE', 'CoChem-SCRIBE', 'CoChem-SEED', 'CoChem-EHS']

out_file = r'C:\Users\ansac\.gemini\antigravity-cli\scratch\submodules_inspection.txt'
with open(out_file, 'w', encoding='utf-8') as out:
    for m in modules_to_inspect:
        mp = os.path.join(repo, m)
        out.write(f"\n========================================================\n")
        out.write(f"MODULE: {m}\n")
        out.write(f"========================================================\n")
        for root, dirs, files in os.walk(mp):
            rel_root = os.path.relpath(root, repo)
            if any(x in rel_root for x in ['.venv', '__pycache__', '.pytest_cache', '.mypy_cache', 'node_modules']):
                continue
            for f in files:
                rel_file = os.path.relpath(os.path.join(root, f), repo)
                out.write(f"  {rel_file}\n")

print(f"Submodules inspection saved to {out_file}")
