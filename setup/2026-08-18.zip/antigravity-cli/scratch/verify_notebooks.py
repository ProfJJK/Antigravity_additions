import re
from pathlib import Path

repo_root = Path(r"D:\__CoChem\GitHub-Repo")
bp_content = (repo_root / "CoChem_Draco_Blueprint.md").read_text(encoding="utf-8")

notebooks = [
  "CoChem-BASE/Start_Here.ipynb",
  "CoChem-BASE/notebooks/CoChem-BASE_Research.ipynb",
  "CoChem-BENCH/notebooks/CoChem-BENCH_Research.ipynb",
  "CoChem-BENCH/notebooks/True_Research_CoChem-BENCH.ipynb",
  "CoChem-CURE/notebooks/CoChem-CURE_Research.ipynb",
  "CoChem-Council/notebooks/CoChem-Council_Research.ipynb",
  "CoChem-EVAL/notebooks/CoChem-EVAL_Research.ipynb",
  "CoChem-GEOM/notebooks/CoChem-GEOM_Research.ipynb",
  "CoChem-GEOM/notebooks/True_Research_CoChem-GEOM.ipynb",
  "CoChem-KINETIC/notebooks/CoChem-KINETIC_Research.ipynb",
  "CoChem-KINETIC/notebooks/True_Research_CoChem-KINETIC.ipynb",
  "CoChem-KINETIC/notebooks/test_tp_grid.ipynb",
  "CoChem-LABS/notebooks/CoChem-LABS_Research.ipynb",
  "CoChem-PLAY/notebooks/CoChem-PLAY_Research.ipynb",
  "CoChem-PULSE/notebooks/CoChem-PULSE_Research.ipynb",
  "CoChem-PULSE/notebooks/True_Research_CoChem-PULSE.ipynb",
  "CoChem-SCAN/notebooks/CoChem-SCAN_Research.ipynb",
  "CoChem-SCAN/notebooks/True_Research_CoChem-SCAN.ipynb",
  "CoChem-SHIFT/notebooks/CoChem-SHIFT_Research.ipynb",
  "CoChem-SHIFT/notebooks/True_Research_CoChem-SHIFT.ipynb",
  "CoChem-SpycFit/notebooks/CoChem-SpycFit_Research.ipynb",
  "CoChem-SpycFit/notebooks/True_Research_CoChem-SpycFit.ipynb",
  "CoChem-TOPOS/notebooks/CoChem-TOPOS_Research.ipynb",
  "CoChem-TOPOS/notebooks/True_Research_CoChem-TOPOS.ipynb",
  "CoChem-TORQ/notebooks/True_Research_CoChem-TORQ.ipynb",
  "tests/test_audit_019.ipynb",
  "tests/test_audit_098.ipynb",
  "tests/test_dock_pharmacophore_parallel.ipynb",
  "tests/test_output.ipynb"
]

missing_nb = []
for nb in notebooks:
    # Match either full path or filename
    fname = Path(nb).name
    if fname not in bp_content:
        missing_nb.append(nb)

print(f"Missing notebooks: {missing_nb} (Total checked: {len(notebooks)}, Found: {len(notebooks) - len(missing_nb)})")
