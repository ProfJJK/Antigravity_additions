import ast
import os

sterile_dir = r"C:\Users\ansac\AppData\Local\Temp\cochem_exec_a1bbecd8a5cc4df6a75ee5044d4a694b"

print("=== AST ANALYSIS OF PYTHON CODE ===")
for root, dirs, files in os.walk(sterile_dir):
    if ".git" in root or "__pycache__" in root or ".pytest_cache" in root:
        continue
    for f in files:
        if not f.endswith(".py"):
            continue
        filepath = os.path.join(root, f)
        rel_path = os.path.relpath(filepath, sterile_dir)
        try:
            with open(filepath, "r", encoding="utf-8") as fh:
                tree = ast.parse(fh.read(), filename=filepath)
            
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    # Check if function body is just pass or docstring + pass
                    body = node.body
                    if len(body) == 1 and isinstance(body[0], ast.Pass):
                        print(f"[EMPTY FUNCTION (pass)] {rel_path}:{node.lineno}: def {node.name}")
                    elif len(body) == 2 and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[1], ast.Pass):
                        print(f"[EMPTY FUNCTION (doc+pass)] {rel_path}:{node.lineno}: def {node.name}")
                    elif len(body) == 1 and isinstance(body[0], ast.Raise) and isinstance(body[0].exc, ast.Name) and body[0].exc.id == "NotImplementedError":
                        print(f"[NOT IMPLEMENTED] {rel_path}:{node.lineno}: def {node.name}")
                elif isinstance(node, ast.ClassDef):
                    # Check class definition
                    pass
        except Exception as e:
            print(f"Error parsing {rel_path}: {e}")
