import sqlite3
import os
import sys

db_path = r"C:\Users\ansac\AppData\Local\Temp\cochem_exec_a1bbecd8a5cc4df6a75ee5044d4a694b\.coverage"
conn = sqlite3.connect(db_path)
c = conn.cursor()
tables = c.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()
print("Tables:", tables)

for t in tables:
    name = t[0]
    count = c.execute(f"SELECT count(*) FROM {name}").fetchone()[0]
    print(f"Table {name}: {count} rows")
    if name == 'file':
        for row in c.execute("SELECT * FROM file").fetchall():
            print("  file:", row)
    elif name == 'meta':
        for row in c.execute("SELECT * FROM meta").fetchall():
            print("  meta:", row)
    elif name == 'context':
        for row in c.execute("SELECT * FROM context").fetchall():
            print("  context:", row)

conn.close()
