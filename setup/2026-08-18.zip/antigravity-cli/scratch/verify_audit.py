import io
import sys
import traceback
from pathlib import Path

# Insert path to target script
sys.path.insert(0, r"C:\Users\ansac\AppData\Local\Temp\cochem_exec_098f38e77194407aacea47349eb492b1\00-SETUP-AA")

print("--- 1. Testing UnicodeEncodeError on cp1252 (regular mode) ---")
try:
    fake_stdout = io.TextIOWrapper(io.BytesIO(), encoding='cp1252')
    old_stdout = sys.stdout
    sys.stdout = fake_stdout
    
    from cochem_geom_setup import GeomEnvironmentOrchestrator
    orch = GeomEnvironmentOrchestrator("test_ws_regular", headless=False)
    orch.setup_environment()
except Exception as e:
    sys.stdout = old_stdout
    print(f"Caught expected error in regular mode: {type(e).__name__}: {e}")
    traceback.print_exc()
else:
    sys.stdout = old_stdout
    print("Regular mode unexpectedly succeeded without UnicodeEncodeError")

print("\n--- 2. Testing UnicodeEncodeError on cp1252 (headless mode) ---")
try:
    fake_stderr = io.TextIOWrapper(io.BytesIO(), encoding='cp1252')
    old_stderr = sys.stderr
    sys.stderr = fake_stderr
    
    orch_hl = GeomEnvironmentOrchestrator("test_ws_hl", headless=True)
    orch_hl.setup_environment()
except Exception as e:
    sys.stderr = old_stderr
    print(f"Caught expected error in headless mode: {type(e).__name__}: {e}")
    traceback.print_exc()
else:
    sys.stderr = old_stderr
    print("Headless mode completed (checking if tqdm wrote to stderr or caught error)")

print("\n--- 3. Testing missing encoding in open() ---")
# Check open calls in cochem_geom_setup.py
with open(r"C:\Users\ansac\AppData\Local\Temp\cochem_exec_098f38e77194407aacea47349eb492b1\00-SETUP-AA\cochem_geom_setup.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

for i, line in enumerate(lines, 1):
    if "open(" in line:
        print(f"Line {i}: {line.strip()}")
