import json
import os
from pathlib import Path

repo_root = Path(r"C:\Users\ansac\AppData\Local\Temp\tmpos7redrb\cochem_exec_3785698f-fce7-4d2b-84ca-4a7fe5e8e390\repo")

print("Scanning all modules...")
for module_dir in sorted(repo_root.glob("CoChem-*")):
    if module_dir.is_dir():
        nbs = list(module_dir.glob("**/*.ipynb"))
        print(f"\nModule: {module_dir.name} (found {len(nbs)} notebooks)")
        for nb_path in nbs:
            if ".trash" in str(nb_path):
                continue
            print(f"  - {nb_path.relative_to(repo_root)}")
            try:
                data = json.loads(nb_path.read_text(encoding="utf-8"))
                cells = data.get("cells", [])
                print(f"    Total cells: {len(cells)}")
                for idx, cell in enumerate(cells):
                    ctype = cell.get("cell_type", "unknown")
                    source = "".join(cell.get("source", []))
                    first_line = source.strip().split("\n")[0] if source.strip() else "(empty)"
                    print(f"      Cell {idx} [{ctype}]: {first_line[:80]}")
            except Exception as e:
                print(f"    Error reading {nb_path}: {e}")
