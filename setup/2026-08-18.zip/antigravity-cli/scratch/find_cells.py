import glob
import json
import sys

sys.stdout.reconfigure(encoding="utf-8")

for nb_path in glob.glob("D:/__CoChem/GitHub-Repo/**/*.ipynb", recursive=True):
    if ".venv" in nb_path:
        continue
    try:
        with open(nb_path, "r", encoding="utf-8") as f:
            nb = json.load(f)
        cells = nb.get("cells", [])
        print(f"\n====================\nNotebook: {nb_path} ({len(cells)} cells)")
        for idx, cell in enumerate(cells):
            src = "".join(cell.get("source", []))
            if "benchmark" in src.lower() or "dft" in src.lower() or "energy" in src.lower() or idx == 0:
                print(f"--- Cell {idx} ({cell.get('cell_type')}) ---")
                print(src[:300])
    except Exception as e:
        print(f"Error {nb_path}: {e}")
