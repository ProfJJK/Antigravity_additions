import os
import json
import glob
import sys

repo = r'D:\__CoChem\GitHub-Repo'
nbs = glob.glob(os.path.join(repo, '**', '*.ipynb'), recursive=True)
nbs = [f for f in nbs if '.venv' not in f and 'site-packages' not in f and '.trash' not in f]
nbs.sort()

out_path = r'C:\Users\ansac\.gemini\antigravity-cli\scratch\notebooks_detail.txt'
with open(out_path, 'w', encoding='utf-8') as out:
    for nb_path in nbs:
        rel = os.path.relpath(nb_path, repo)
        with open(nb_path, 'r', encoding='utf-8') as f:
            nb = json.load(f)
        cells = nb.get('cells', [])
        out.write("=" * 80 + "\n")
        out.write(f"NOTEBOOK: {rel} ({len(cells)} cells)\n")
        out.write("=" * 80 + "\n")
        for idx, c in enumerate(cells):
            ctype = c.get('cell_type')
            src = ''.join(c.get('source', []))
            out.write(f"--- Cell {idx:02d} [{ctype}] ---\n")
            out.write(src + "\n\n")

print(f"Wrote full notebook details to {out_path}")
