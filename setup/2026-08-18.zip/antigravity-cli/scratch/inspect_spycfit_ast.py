import ast
from pathlib import Path

spycfit_dir = Path(r"C:\Users\ansac\AppData\Local\Temp\tmpos7redrb\cochem_exec_3785698f-fce7-4d2b-84ca-4a7fe5e8e390\repo\CoChem-SpycFit")

for py_path in sorted(spycfit_dir.rglob("*.py")):
    if "__pycache__" in str(py_path):
        continue
    rel = py_path.relative_to(spycfit_dir)
    print(f"\n==================== {rel} ====================")
    try:
        content = py_path.read_text(encoding="utf-8")
        tree = ast.parse(content)
        doc = ast.get_docstring(tree)
        if doc:
            print(f"Docstring: {doc[:300]}...")
        classes = [n.name for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]
        funcs = [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
        print(f"Classes: {classes}")
        print(f"Functions: {funcs}")
    except Exception as e:
        print(f"Error parsing {py_path}: {e}")
