import os
import re

sterile_dir = r"C:\Users\ansac\AppData\Local\Temp\cochem_exec_a1bbecd8a5cc4df6a75ee5044d4a694b"

search_terms = ["Calc_Hess", "InHess", "defgrid", "Grid3", "Grid5", "mock", "stub", "fake", "placeholder", "D:\\Gdrive"]

for root, dirs, files in os.walk(sterile_dir):
    if ".git" in root or "__pycache__" in root or ".pytest_cache" in root:
        continue
    for f in files:
        if not (f.endswith(".py") or f.endswith(".md") or f.endswith(".inp") or f.endswith(".tex")):
            continue
        filepath = os.path.join(root, f)
        rel_path = os.path.relpath(filepath, sterile_dir)
        try:
            with open(filepath, "r", encoding="utf-8", errors="replace") as fh:
                for line_no, line in enumerate(fh, 1):
                    for term in search_terms:
                        if term.lower() in line.lower():
                            print(f"[{term}] {rel_path}:{line_no}: {line.strip()[:140]}")
        except Exception as e:
            pass
