import sys
sys.path.insert(0, r"D:\__CoChem\GitHub-Repo\CoChem-Council")
from cochem_council.cochem_anti_spoof import (
    scan_source_code,
    scan_prompt_text,
    scan_file,
    scan_directory,
    trigger_emergency_council_summit,
    handle_missing_data,
    BANNED_KEYWORDS,
    BANNED_SYNONYMS,
    BANNED_IMPORTS,
    BANNED_COMMENT_REGEXES,
)

print("Running Adversarial Anti-Spoof Test Suite...")

cases = {
    # 1. Banned terms in variables
    "banned_var_mock": ("mock_obj = 1", True),
    "banned_var_example": ("example_data = [1, 2]", True),
    "banned_var_stub": ("stub_fn = lambda: 1", True),
    "banned_var_dummy": ("dummy_val = 0.5", True),
    "banned_var_placeholder": ("placeholder_tensor = []", True),
    "banned_var_fake": ("fake_coords = [0, 0, 0]", True),
    "banned_var_sample": ("sample_points = 10", True),
    
    # 2. Banned terms in functions / classes / args
    "banned_func_mock": ("def run_mock(): return 1", True),
    "banned_func_example": ("def run_example(): return 1", True),
    "banned_func_stub": ("def compute_stub(): return 1", True),
    "banned_func_dummy": ("def dummy_run(): return 1", True),
    "banned_func_placeholder": ("def placeholder_calc(): return 1", True),
    "banned_func_fake": ("def fake_energy(): return 1", True),
    "banned_func_sample": ("def sample_mesh(): return 1", True),
    "banned_class_mock": ("class MockDriver: pass", True),
    "banned_arg_dummy": ("def calc(dummy_arg=1): return dummy_arg", True),
    
    # 3. Comments and stubs
    "comment_todo_implement": ("# TODO: implement this\nx = 1", True),
    "comment_todo": ("# TODO finish work\nx = 1", True),
    "comment_fixme": ("# FIXME broken calc\nx = 1", True),
    "comment_xxx": ("# XXX check here\nx = 1", True),
    "comment_banned_mock": ("# use mock driver\nx = 1", True),
    "stub_pass": ("def f():\n    pass", True),
    "stub_raise_notimplemented": ("def f():\n    raise NotImplementedError('todo')", True),
    "stub_raise_runtime": ("def f():\n    raise RuntimeError('not implemented')", True),
    "stub_ellipsis": ("def f():\n    ...", True),
    "stub_docstring_pass": ("def f():\n    '''Some docstring.'''\n    pass", True),
    
    # 4. Prohibited imports
    "import_unittest_mock": ("import unittest.mock", True),
    "from_unittest_mock": ("from unittest.mock import MagicMock", True),
    "import_mock": ("import mock", True),
    "import_pytest_mock": ("import pytest_mock", True),
    "import_dask": ("import dask", True),
    "import_parsl": ("import parsl", True),
    "import_multiprocessing": ("import multiprocessing", True),
    "import_concurrent_futures": ("import concurrent.futures", True),
    
    # 5. Clean / legitimate code
    "clean_math": ("def add(a: float, b: float) -> float:\n    return a + b", False),
    "clean_class": ("class SCFEngine:\n    def __init__(self, tol: float = 1e-6):\n        self.tol = tol\n    def run(self) -> float:\n        return -76.0\n", False),
    
    # 6. Exemption phrases
    "exempt_zero_stub": ("# zero-stub check\ndef mock_verifier():\n    return True", False),
}

results = {}
for name, (code, expect_violation) in cases.items():
    v = scan_source_code(code, filename=name + ".py")
    has_violation = len(v) > 0
    passed = has_violation == expect_violation
    results[name] = {"passed": passed, "expected": expect_violation, "got": has_violation, "violations": len(v)}
    status = "PASS" if passed else "FAIL"
    print(f"[{status}] {name}: expected={expect_violation}, got={has_violation} ({len(v)} violations)")

all_passed = all(r["passed"] for r in results.values())
print(f"\nOverall adversarial test status: {'ALL PASSED' if all_passed else 'SOME FAILED'}")
