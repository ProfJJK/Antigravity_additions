import os
import re

sterile_dir = r"C:\Users\ansac\AppData\Local\Temp\cochem_exec_a1bbecd8a5cc4df6a75ee5044d4a694b"

patterns = {
    "mock_imports": re.compile(r"(unittest\.mock|from unittest import mock|import mock|MagicMock|unittest\.mock\.patch|patch\()"),
    "placeholders": re.compile(r"\b(TODO|FIXME|XXX|placeholder|stub|dummy|mock|fake|spoof|NotImplemented|raise NotImplementedError)\b", re.IGNORECASE),
    "pass_statements": re.compile(r"^\s*pass\s*(#.*)?$"),
}

print("=== AUDIT FOR MOCKS, STUBS, PLACEHOLDERS ===")
for root, dirs, files in os.walk(sterile_dir):
    if ".git" in root or "__pycache__" in root or ".pytest_cache" in root:
        continue
    for f in files:
        if not (f.endswith(".py") or f.endswith(".ipynb") or f.endswith(".md")):
            continue
        filepath = os.path.join(root, f)
        rel_path = os.path.relpath(filepath, sterile_dir)
        try:
            with open(filepath, "r", encoding="utf-8", errors="replace") as fh:
                lines = fh.readlines()
            for line_idx, line in enumerate(lines, 1):
                for pat_name, pat in patterns.items():
                    if pat.search(line):
                        # Filter out innocuous doc/test lines if needed, but let's report
                        print(f"[{pat_name}] {rel_path}:{line_idx}: {line.strip()[:120]}")
        except Exception as e:
            print(f"Error reading {rel_path}: {e}")
