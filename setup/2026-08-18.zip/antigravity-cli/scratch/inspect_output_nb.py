import json
import sys

sys.stdout.reconfigure(encoding="utf-8")
nb = json.load(open(r"C:\Users\ansac\.gemini\antigravity-cli\scratch\test_bench_research_out.ipynb", encoding="utf-8"))
for i, cell in enumerate(nb["cells"]):
    print(f"=== Cell {i} ({cell['cell_type']}) ===")
    print("Source:", "".join(cell.get("source", [])))
    print("Outputs:", json.dumps(cell.get("outputs", []), indent=2))
