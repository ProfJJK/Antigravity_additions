import re

with open(r"D:\__CoChem\GitHub-Repo\CoChem-BASE\.agents\cochem-tester.agent.md", "r", encoding="utf-8") as f:
    text = f.read()

# Check headers
headers = [line for line in text.splitlines() if line.startswith("#")]
print(f"Total headers: {len(headers)}")
for h in headers:
    print(h)

# Check code blocks matching backticks
backtick_counts = [len(m) for m in re.findall(r"`+", text)]
print(f"\nBacktick patterns: {set(backtick_counts)}")
fenced_blocks = text.count("```")
print(f"Triple backticks count (must be even): {fenced_blocks}")

# Check YAML frontmatter delimiter count
print(f"Frontmatter '---' count: {text.count('---')}")
