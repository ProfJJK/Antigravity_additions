import os
import re
from pathlib import Path

repo_root = Path(r"D:\__CoChem\GitHub-Repo")
bp1_path = repo_root / "CoChem_Draco_Blueprint.md"
bp2_path = repo_root / "GitHub-Repo_Draco_Blueprint.md"

print(f"Checking existence:")
print(f"BP1 exists: {bp1_path.exists()}, Size: {bp1_path.stat().st_size if bp1_path.exists() else 0}")
print(f"BP2 exists: {bp2_path.exists()}, Size: {bp2_path.stat().st_size if bp2_path.exists() else 0}")

bp1_content = bp1_path.read_text(encoding="utf-8")
bp2_content = bp2_path.read_text(encoding="utf-8")

print(f"BP1 == BP2: {bp1_content == bp2_content}")

# 1. Two-Pass Blueprint structure adheres to Stage 1 discovery (Zero tests executed in Stage 1).
has_stage1 = "Stage 1 (Two-Pass Discovery & Granular Blueprinting)" in bp1_content
has_zero_tests = "Zero Tests Executed in Stage 1" in bp1_content
all_unchecked = "[x]" not in bp1_content and "[X]" not in bp1_content
print(f"1. Stage 1 markers: has_stage1={has_stage1}, has_zero_tests={has_zero_tests}, all_unchecked={all_unchecked}")

# 2. Method Matrix compliance: Conformer generation (CREST/ORCA GOAT), Grid definitions (defgrid1 -> defgrid3), D3/D4 dispersion, S^2 spin contamination guard (>10% halt).
has_crest_goat = "CREST / ORCA GOAT" in bp1_content or "CREST/ORCA GOAT" in bp1_content
has_grid = "defgrid1" in bp1_content and "defgrid3" in bp1_content
has_disp = "D3" in bp1_content and "D4" in bp1_content
has_spin = "S^2" in bp1_content or "\\langle S^2 \\rangle" in bp1_content or "10%" in bp1_content
print(f"2. Method matrix markers: crest_goat={has_crest_goat}, grid={has_grid}, disp={has_disp}, spin={has_spin}")

# 3. Anti-Spoofing & Immutability: No mocks, stubs, or fake data.
has_anti_spoof = "Zero-Mock Anti-Spoofing Protocol" in bp1_content
has_no_mocks = "forbidden mock frameworks" in bp1_content or "unittest.mock" in bp1_content
has_immutability = "Immutability" in bp1_content or "hashring" in bp1_content.lower()
print(f"3. Anti-spoofing markers: anti_spoof={has_anti_spoof}, no_mocks={has_no_mocks}, immutability={has_immutability}")

# 4. Root cause and anti-patching mandates are fully integrated.
has_root_cause = "Root Cause" in bp1_content and "If-Statements of Shame" in bp1_content
print(f"4. Root cause markers: root_cause={has_root_cause}")

# 5. Completeness: All CoChem research modules (BASE, TOPOS, TORQ, SpycFit, GEOM, CATALYST, SCRIBE, BENCH, KINETIC, LUMOS, MAGE, NODE, ORACLE, PULSE, SCAN, SHIFT), teaching modules (CURE, EVAL, LABS, PLAY, SEED, EHS, Council), and root test suites are mapped.
expected_modules = [
    "BASE", "TOPOS", "TORQ", "SpycFit", "GEOM", "CATALYST", "SCRIBE", "BENCH",
    "KINETIC", "LUMOS", "MAGE", "NODE", "ORACLE", "PULSE", "SCAN", "SHIFT",
    "CURE", "EVAL", "LABS", "PLAY", "SEED", "EHS", "Council"
]

missing_modules = []
for mod in expected_modules:
    if f"CoChem-{mod}" not in bp1_content:
        missing_modules.append(mod)

print(f"5. Module completeness: missing={missing_modules} (Total expected: {len(expected_modules)}, Found: {len(expected_modules) - len(missing_modules)})")

# Check test files in repo vs mapped in blueprint
test_files_on_disk = []
for root, dirs, files in os.walk(repo_root):
    if any(x in root for x in [".venv", ".conda", ".git", ".trash"]):
        continue
    for f in files:
        if (f.startswith("test_") or f.endswith("_test.py")) and (f.endswith(".py") or f.endswith(".ipynb")):
            rel_path = os.path.relpath(os.path.join(root, f), repo_root).replace("\\", "/")
            test_files_on_disk.append((f, rel_path))

print(f"Total test files on disk (excluding .venv/.conda/.trash): {len(test_files_on_disk)}")

# Check how many of these test files are mentioned in BP1
mentioned = 0
unmentioned = []
for fname, rpath in test_files_on_disk:
    if fname in bp1_content or rpath in bp1_content:
        mentioned += 1
    else:
        unmentioned.append(rpath)

print(f"Test files mapped in BP1: {mentioned}/{len(test_files_on_disk)}")
if unmentioned:
    print(f"Sample unmentioned ({len(unmentioned)} total): {unmentioned[:10]}")

# Check for placeholders, ellipses, stubs, TODOs
placeholders = []
for pattern in [r"\bTODO\b", r"\bFIXME\b", r"\bTBD\b", r"\.\.\.", r"placeholder", r"stub", r"dummy"]:
    matches = re.findall(pattern, bp1_content, re.IGNORECASE)
    if matches:
        placeholders.append((pattern, len(matches)))
print(f"Placeholders/stubs in BP: {placeholders}")
