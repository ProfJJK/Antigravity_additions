import json
import sys

sys.stdout.reconfigure(encoding="utf-8")
with open("D:/__CoChem/GitHub-Repo/CoChem-BASE/Start_Here.ipynb", "r", encoding="utf-8") as f:
    nb = json.load(f)

for idx, cell in enumerate(nb["cells"]):
    print(f"=== Cell {idx} ({cell['cell_type']}) ===")
    print("".join(cell["source"]))
