import json
from pathlib import Path

spycfit_dir = Path(r"C:\Users\ansac\AppData\Local\Temp\tmpos7redrb\cochem_exec_3785698f-fce7-4d2b-84ca-4a7fe5e8e390\repo\CoChem-SpycFit")

print("=== CoChem-SpycFit_Research.ipynb ===")
nb_path1 = spycfit_dir / "notebooks" / "CoChem-SpycFit_Research.ipynb"
if nb_path1.exists():
    data = json.loads(nb_path1.read_text(encoding="utf-8"))
    for idx, cell in enumerate(data.get("cells", [])):
        print(f"\n--- Cell {idx} [{cell.get('cell_type')}] ---")
        print("".join(cell.get("source", [])))

print("\n=== True_Research_CoChem-SpycFit.ipynb ===")
nb_path2 = spycfit_dir / "notebooks" / "True_Research_CoChem-SpycFit.ipynb"
if nb_path2.exists():
    data = json.loads(nb_path2.read_text(encoding="utf-8"))
    for idx, cell in enumerate(data.get("cells", [])):
        print(f"\n--- Cell {idx} [{cell.get('cell_type')}] ---")
        print("".join(cell.get("source", [])))

print("\n=== True_Research_CoChem-SpycFit.py ===")
py_path = spycfit_dir / "notebooks" / "True_Research_CoChem-SpycFit.py"
if py_path.exists():
    print(py_path.read_text(encoding="utf-8"))
