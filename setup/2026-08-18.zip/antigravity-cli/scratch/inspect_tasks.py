import glob
import sys

sys.stdout.reconfigure(encoding="utf-8")

for fpath in glob.glob("D:/__CoChem/GitHub-Repo/.docs/problems/**/*Cell_0_Execution*.md", recursive=True):
    print("=" * 60)
    print(fpath)
    with open(fpath, "r", encoding="utf-8") as f:
        print(f.read())
