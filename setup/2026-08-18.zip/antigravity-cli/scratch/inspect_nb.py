import json
import glob
import sys

sys.stdout.reconfigure(encoding="utf-8")

print("Checking notebooks in CoChem-BENCH:")
for nb_path in glob.glob("D:/__CoChem/GitHub-Repo/CoChem-BENCH/**/*.ipynb", recursive=True):
    print("=" * 60)
    print(nb_path)
    with open(nb_path, "r", encoding="utf-8") as f:
        nb = json.load(f)
    for idx, cell in enumerate(nb.get("cells", [])):
        print(f"\n--- Cell {idx} ({cell.get('cell_type')}) ---")
        print("".join(cell.get("source", [])))
