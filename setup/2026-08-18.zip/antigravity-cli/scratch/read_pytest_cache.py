import os
import json

sterile_dir = r"C:\Users\ansac\AppData\Local\Temp\cochem_exec_a1bbecd8a5cc4df6a75ee5044d4a694b"

print("--- .pytest_cache nodeids ---")
nodeids_path = os.path.join(sterile_dir, ".pytest_cache", "v", "cache", "nodeids")
if os.path.exists(nodeids_path):
    with open(nodeids_path, "r", encoding="utf-8") as f:
        print(f.read())

print("--- .pytest_cache lastfailed ---")
lastfailed_path = os.path.join(sterile_dir, ".pytest_cache", "v", "cache", "lastfailed")
if os.path.exists(lastfailed_path):
    with open(lastfailed_path, "r", encoding="utf-8") as f:
        print(f.read())
