import os
import json
import glob

repo = r'D:\__CoChem\GitHub-Repo'
nbs = glob.glob(os.path.join(repo, '**', '*.ipynb'), recursive=True)
nbs = [f for f in nbs if '.venv' not in f and 'site-packages' not in f and '.trash' not in f]
nbs.sort()

print(f"Total active notebooks: {len(nbs)}")
for nb_path in nbs:
    rel = os.path.relpath(nb_path, repo)
    try:
        with open(nb_path, 'r', encoding='utf-8') as f:
            nb = json.load(f)
        cells = nb.get('cells', [])
        print(f"\n=== Notebook: {rel} ({len(cells)} cells) ===")
        for idx, c in enumerate(cells):
            ctype = c.get('cell_type')
            src = ''.join(c.get('source', []))
            lines = [line.strip() for line in src.split('\n') if line.strip()]
            summary = " | ".join(lines[:3])[:140] if lines else "(empty)"
            print(f"  Cell {idx:02d} [{ctype}]: {summary}")
    except Exception as e:
        print(f"  Error loading {rel}: {e}")
