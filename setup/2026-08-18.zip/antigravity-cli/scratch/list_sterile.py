import os
import glob

sterile_dir = r"C:\Users\ansac\AppData\Local\Temp\cochem_exec_a1bbecd8a5cc4df6a75ee5044d4a694b"

print("--- Listing all files in sterile workspace ---")
for root, dirs, files in os.walk(sterile_dir):
    for f in files:
        full = os.path.join(root, f)
        rel = os.path.relpath(full, sterile_dir)
        print(f"{rel} ({os.path.getsize(full)} bytes)")
