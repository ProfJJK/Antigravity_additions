import sys
sys.path.insert(0, r"D:\__CoChem\GitHub-Repo\CoChem-Council")
from cochem_council.cochem_anti_spoof import (
    scan_source_code,
    scan_prompt_text,
    scan_file,
    scan_directory,
    trigger_emergency_council_summit,
    handle_missing_data,
    BANNED_KEYWORDS,
    BANNED_SYNONYMS,
    BANNED_IMPORTS,
    BANNED_COMMENT_REGEXES,
)

print("=== DEEP ADVERSARIAL AUDIT ===")

# Test 1: Comments with embedded banned keywords
comments = [
    "# mock",
    "# mock data",
    "# please use mock",
    "# temporary stub here",
    "# this is a dummy calculation",
    "# placeholder for gradients",
    "# fake data generator",
    "# sample points for PES",
    "# TODO: implement something",
    "# TODO implement",
    "# TODO",
]

print("\n--- Comment Matching Analysis ---")
for c in comments:
    v = scan_source_code(c + "\nx = 1\n")
    print(f"Comment: '{c}' -> Violations: {len(v)}")

# Test 2: Banned keywords inside strings vs identifiers
strings_and_code = [
    ("a = 'mock'", "string literal with 'mock'"),
    ("a = 'dummy'", "string literal with 'dummy'"),
    ("a = 'TODO: implement'", "string literal with 'TODO: implement'"),
    ("a = 'placeholder'", "string literal with 'placeholder'"),
    ("a = 'fake'", "string literal with 'fake'"),
    ("a = 'sample'", "string literal with 'sample'"),
    ("mock_var = 1", "variable name 'mock_var'"),
    ("my_mock = 1", "variable name 'my_mock'"),
    ("is_mocked = 1", "variable name 'is_mocked'"),
    ("mocking = 1", "variable name 'mocking'"),
    ("unmock = 1", "variable name 'unmock'"),
]

print("\n--- String & Identifier Matching Analysis ---")
for code, desc in strings_and_code:
    v = scan_source_code(code)
    print(f"{desc} (`{code}`) -> Violations: {len(v)} {[x.rule_id + ':' + x.term for x in v]}")

# Test 3: Prompt scanner analysis
prompts = [
    "Generate a mock calculation.",
    "Do not use mock calculations.", # contains mock
    "This is an example of HF.",
    "Create a dummy tensor.",
    "Fill in the placeholder.",
    "Return fake gradients.",
    "Collect a sample.",
    "# TODO: implement the parser",
]

print("\n--- Prompt Scanning Analysis ---")
for p in prompts:
    v = scan_prompt_text(p)
    print(f"Prompt: '{p}' -> Violations: {len(v)} {[x.term for x in v]}")
