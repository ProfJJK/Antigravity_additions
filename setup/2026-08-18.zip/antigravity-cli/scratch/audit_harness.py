import os
import sys
import re
import tempfile
import shutil
from pathlib import Path

# Extract blocks from markdown specification
spec_path = Path(r"C:\Users\ansac\AppData\Local\Temp\cochem_exec_4969b29ce9b04f9db05e316dda2dd648\Stage 0.0 Master Setup.md")
text = spec_path.read_text(encoding="utf-8")

blocks = re.findall(r'```python\n(.*?)```', text, re.DOTALL)
print(f"Extracted {len(blocks)} python code blocks.")

# Combine relevant code: Block 0 (imports), Block 1 (models), Block 4 (orchestrator), Block 5 (logging)
test_code = '\n'.join([blocks[0], blocks[1], blocks[4], blocks[5]])

test_dir = Path(tempfile.mkdtemp(prefix="cochem_audit_"))
test_py = test_dir / "cochem_geom_setup.py"
test_py.write_text(test_code, encoding="utf-8")

print(f"Wrote module to {test_py}")

# Write dedicated test script
test_runner = test_dir / "test_module.py"
runner_content = """
import sys
import os
import tempfile
import shutil
from pathlib import Path

# Add directory to sys.path
sys.path.insert(0, str(Path(__file__).parent))

from cochem_geom_setup import (
    WorkspaceConfig,
    HDF5DatasetAllocationModel,
    GeomEnvironmentOrchestrator,
    ProvenanceRegistryModel,
    CoChemTag,
    HardwareProfileModel,
    HDF5LockingError,
    setup_logging
)

def run_tests():
    temp_root = Path(tempfile.mkdtemp(prefix="cochem_audit_ws_"))
    try:
        print("[TEST 1] WorkspaceConfig and model instantiation...")
        cfg = WorkspaceConfig(
            workspace_name="audit_test_ws",
            root_artifacts_dir=temp_root,
            isolation_mode=True
        )
        assert cfg.workspace_path == temp_root / "audit_test_ws"
        alloc = HDF5DatasetAllocationModel()
        assert alloc.chunk_size_rotational == (100,)
        assert alloc.chunk_size_coords == (100, 50, 3)
        print(" -> PASSED")

        print("[TEST 2] GeomEnvironmentOrchestrator initialization...")
        orch = GeomEnvironmentOrchestrator(cfg)
        assert orch.hardware_profile.cpu_cores_physical >= 1
        assert orch.hardware_profile.system_ram_mb >= 1024
        print(f" -> Hardware profile: CPU cores={orch.hardware_profile.cpu_cores_physical}, RAM={orch.hardware_profile.system_ram_mb}MB")
        print(" -> PASSED")

        print("[TEST 3] Workspace directory topology & permission creation...")
        orch.initialize_workspace()
        for sub in ["hdf5", "logs", "inputs", "outputs", "checkpoints", "locks"]:
            assert (cfg.workspace_path / sub).is_dir(), f"Missing subdir: {sub}"
        print(" -> PASSED")

        print("[TEST 4] Quarantine integrity check...")
        orch._verify_quarantine_integrity()
        print(" -> PASSED")

        print("[TEST 5] HDF5 SWMR lake initialization & pre-allocation...")
        h5_path = orch.initialize_swmr_lake(alloc)
        assert h5_path.is_file()
        import h5py
        with h5py.File(h5_path, "r", libver="latest", swmr=True) as f:
            assert "rotational_constants" in f
            assert "centrifugal_distortion" in f
            assert "inertial_tensors" in f
            assert "structures" in f
            assert f["rotational_constants/A"].shape == (0,)
            assert f["rotational_constants/A"].chunks == (100,)
            assert f["rotational_constants/A"].attrs["units"] == "MHz"
            assert f["rotational_constants/A"].attrs["cochem_tag"] == "[D]"
            assert f["structures/r_0"].shape == (0, 50, 3)
            assert f["structures/r_0"].chunks == (100, 50, 3)
            assert f["structures/r_e_SE"].attrs["cochem_tag"] == "[E]"
            assert f.swmr_mode is True
        print(f" -> SWMR file verified at {h5_path}")
        print(" -> PASSED")

        print("[TEST 6] Literature citation harvesting in references.bib...")
        bib_path = orch.seed_references_bib()
        assert bib_path.is_file()
        bib_content = bib_path.read_text(encoding="utf-8")
        expected_dois = [
            "10.1016/0022-2852(91)90393-O",
            "10.1119/1.1933338",
            "10.1006/jmsp.1999.7843",
            "10.1080/00268976800101301",
            "10.1063/1.1744602",
            "10.1063/1.3382344",
            "10.1021/acs.jctc.7b00118",
            "10.1063/5.0004608",
        ]
        for doi in expected_dois:
            assert doi in bib_content, f"Missing DOI: {doi}"
        print(" -> All 8 DOIs verified in references.bib")
        print(" -> PASSED")

        print("[TEST 7] Physical benchmark coordinate seeding...")
        benchmarks = orch.seed_benchmark_molecules()
        assert "water_dimer.xyz" in benchmarks
        assert "trans_formamide.xyz" in benchmarks
        assert "ocs_linear.xyz" in benchmarks
        for name, p in benchmarks.items():
            assert p.is_file(), f"Missing benchmark file: {name}"
            xyz_data = p.read_text(encoding="utf-8").strip().splitlines()
            num_atoms = int(xyz_data[0])
            coords_lines = xyz_data[2:]
            assert len(coords_lines) == num_atoms, f"Atom count mismatch in {name}: expected {num_atoms}, got {len(coords_lines)}"
        print(" -> 3 benchmark geometries verified (valid XYZ formatting & atom counts)")
        print(" -> PASSED")

        print("[TEST 8] Cryptographic provenance registry generation...")
        prov = orch.initialize_provenance(git_commit="deadbeef1234567", config_files=[bib_path])
        assert (cfg.workspace_path / "geom_provenance.json").is_file()
        assert prov.session_id.startswith("cochem") or len(prov.session_id) == 36
        assert "pydantic" in prov.software_dependencies
        assert "psutil" in prov.software_dependencies
        assert "h5py" in prov.software_dependencies
        assert "numpy" in prov.software_dependencies
        assert "filelock" in prov.software_dependencies
        assert len(prov.sha256_tree) > 0
        print(f" -> Provenance validated (session_id={prov.session_id}, timestamp={prov.timestamp_utc})")
        print(" -> PASSED")

        print("[TEST 9] Automated 4-subprocess SWMR concurrency stress testing...")
        stress_res = orch.run_swmr_concurrency_stress_test(num_readers=4, max_latency_ms=50.0)
        assert stress_res is True
        print(" -> Concurrency stress test passed with 4 parallel worker subprocesses")
        print(" -> PASSED")

        print("[TEST 10] Headless logging setup...")
        setup_logging(headless=True, log_file=cfg.workspace_path / "logs" / "init.log")
        import logging
        logger = logging.getLogger("cochem.test")
        logger.info("Test log line via TqdmLoggingHandler")
        assert (cfg.workspace_path / "logs" / "init.log").is_file()
        print(" -> Headless tqdm logging handler verified")
        print(" -> PASSED")

        print("=== ALL 10 TESTS COMPLETED SUCCESSFULLY ===")
    finally:
        shutil.rmtree(temp_root, ignore_errors=True)

if __name__ == "__main__":
    run_tests()
"""
test_runner.write_text(runner_content, encoding="utf-8")
print(f"Wrote test runner to {test_runner}")
