import re

with open(r"D:\__CoChem\GitHub-Repo\CoChem-BASE\.agents\cochem-tester.agent.md", "r", encoding="utf-8") as f:
    text = f.read()

tags = re.findall(r"</?([A-Za-z0-9_]+)>", text)
print("Tags found in order:", tags)

stack = []
for t in re.findall(r"<(/?[A-Za-z0-9_]+)>", text):
    if not t.startswith("/"):
        stack.append(t)
    else:
        closing = t[1:]
        if stack and stack[-1] == closing:
            stack.pop()
        else:
            print(f"Mismatched tag: expected </{stack[-1] if stack else 'None'}>, got </{closing}>")

if not stack:
    print("All XML-style tags are perfectly balanced and closed!")
else:
    print("Unclosed tags:", stack)
