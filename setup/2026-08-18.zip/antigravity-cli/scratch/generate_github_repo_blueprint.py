import os
import sys
import fnmatch
from pathlib import Path
import psutil

def sweep_zombies() -> None:
    """Sweep zombie processes using psutil if any subprocesses were invoked."""
    current_process = psutil.Process()
    for child in current_process.children(recursive=True):
        if child.status() == psutil.STATUS_ZOMBIE:
            child.wait(timeout=1)

def generate_blueprint(repo_path: Path, artifacts_dir: Path) -> Path:
    repo_path = repo_path.resolve()
    artifacts_dir = artifacts_dir.resolve()
    
    module_name = repo_path.name
    output_file = artifacts_dir / f"{module_name}_File_Blueprint.md"
    
    ignored_dir_names = {".git", "__pycache__", "artifacts"}
    ignored_file_names = {"swarm_state.json"}
    ignored_patterns = ["*.log", "*.lock"]
    
    # Ensure artifacts directory exists
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    
    # Collect relative paths using pathlib and os.walk
    # Memory-efficient sorting and writing
    relative_paths = []
    
    for root, dirs, files in os.walk(repo_path):
        root_path = Path(root)
        
        # In-place directory pruning to avoid traversing ignored directories
        dirs[:] = [d for d in dirs if d not in ignored_dir_names]
        
        for file_name in files:
            # Check explicit exclusions
            if file_name in ignored_file_names:
                continue
            if any(fnmatch.fnmatch(file_name, pattern) for pattern in ignored_patterns):
                continue
            
            file_path = root_path / file_name
            
            # Check structural safety / read permissions
            if not os.access(file_path, os.R_OK):
                continue
                
            rel_path = file_path.relative_to(repo_path).as_posix()
            relative_paths.append(rel_path)
            
    # Sort paths for deterministic ordering
    relative_paths.sort()
    
    # Write directly to destination blueprint file
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(f"# {module_name} File Blueprint\n\n")
        for rel_path in relative_paths:
            f.write(f"- [ ] {rel_path}\n")
            
    sweep_zombies()
    return output_file

if __name__ == "__main__":
    if len(sys.argv) >= 3:
        target_repo = Path(sys.argv[1])
        artifacts_dir = Path(sys.argv[2])
    else:
        target_repo = Path(r"d:\__CoChem\GitHub-Repo")
        artifacts_dir = Path(r"D:\Gdrive\__agentic\.prompts\artifacts")
        
    out = generate_blueprint(target_repo, artifacts_dir)
    print(f"File Blueprint successfully generated at: {out.resolve()}")
