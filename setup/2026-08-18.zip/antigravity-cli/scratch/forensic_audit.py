import os
import glob
import re
import yaml

agent_file = r"D:\__CoChem\GitHub-Repo\CoChem-BASE\.agents\cochem-tester.agent.md"
skill_file = r"C:\Users\ansac\.gemini\config\skills\agent-cochem-tester\SKILL.md"
log_file = r"D:\__CoChem\GitHub-Repo\CoChem-BASE\.docs\.audit\.logs\task_10.log"
task_file = r"D:\__CoChem\GitHub-Repo\CoChem-BASE\.docs\.audit\.repo_lists\task_10.txt"

print("=== 1. FILE EXISTENCE & BINARY COMPARISON ===")
print("Agent file exists:", os.path.exists(agent_file))
print("Skill file exists:", os.path.exists(skill_file))
print("Log file exists:", os.path.exists(log_file))
print("Task file exists:", os.path.exists(task_file))

with open(agent_file, "rb") as f:
    agent_bytes = f.read()

with open(skill_file, "rb") as f:
    skill_bytes = f.read()

print("Agent bytes len:", len(agent_bytes))
print("Skill bytes len:", len(skill_bytes))
print("Byte-level exact match:", agent_bytes == skill_bytes)
print("Agent CR count:", agent_bytes.count(b"\r"))
print("Agent LF count:", agent_bytes.count(b"\n"))
print("Skill CR count:", skill_bytes.count(b"\r"))
print("Skill LF count:", skill_bytes.count(b"\n"))

print("\n=== 2. YAML FRONTMATTER CHECK ===")
content = agent_bytes.decode("utf-8")
parts = content.split("---")
if len(parts) >= 3:
    yaml_str = parts[1]
    parsed_yaml = yaml.safe_load(yaml_str)
    print("YAML frontmatter parsed successfully:")
    for k, v in parsed_yaml.items():
        print(f"  {k}: {v}")
else:
    print("ERROR: YAML frontmatter not found or malformed")

print("\n=== 3. SECTION & CLAIM AUDIT ===")
claims = [
    ("Conformer Search (CREST/ORCA GOAT)", r"CREST/ORCA GOAT"),
    ("Dynamic Grids (defgrid1 -> defgrid3)", r"defgrid1.*defgrid3"),
    ("Banned Grid3/Grid5", r"Grid3/Grid5"),
    ("Tight Convergence TolMaxG 1e-5", r"TolMaxG 1e-5"),
    ("Frozen-Monomer Protocol", r"Frozen-Monomer Protocol"),
    ("Hessian Preconditioning (InHess XTB2 / Lindh)", r"InHess XTB2|Lindh"),
    ("Banned Calc_Hess true", r"Calc_Hess true"),
    ("D3/D4 dispersion", r"D3/D4"),
    ("Spin Contamination < 10%", r"\\langle S\^2 \\rangle|S\^2.*10%"),
    ("Provenance tags [M], [D], [E]", r"\[M\].*\[D\].*\[E\]"),
    ("Zero-Mock (no unittest.mock.patch, MagicMock)", r"unittest\.mock\.patch|MagicMock"),
    ("Missing Binary Protocol ([ERR_MISSING_BIN])", r"\[ERR_MISSING_BIN\]"),
    ("Chaos Event Injections (NaN, inf, 1e-9)", r"NaN.*inf.*1e-9"),
    ("Headless execution (pytest, jupyter nbconvert, papermill)", r"jupyter nbconvert.*papermill"),
    ("Process Lifecycle (PID, psutil, Get-Process)", r"psutil.*Get-Process|Get-Process.*psutil"),
    ("Stranded Process Sweep (atexit / psutil)", r"atexit|zombie"),
    ("Temporary File Cleanup (tmp_path)", r"tmp_path"),
    ("No-Kill Mandate (shutil.move to trash)", r"shutil\.move.*trash"),
    ("Asymmetric Verification (/tmp/cochem_exec_<uuid>/)", r"/tmp/cochem_exec_<uuid>/"),
    ("State Machine Orchestration (.repo_lists, .logs)", r"\.repo_lists.*\.logs"),
    ("Prompt Match Verification Gate", r"\[PROMPT MATCH VERIFICATION\]"),
    ("Subagent Garbage Collection (manage_subagents kill)", r"manage_subagents.*kill"),
    ("Edit-First In-Place Modification Mandate", r"EDIT-FIRST")
]

for label, pat in claims:
    matches = re.findall(pat, content, re.IGNORECASE | re.DOTALL)
    print(f"[{'PASS' if matches else 'FAIL'}] {label}")

print("\n=== 4. MOCK / BANNED TERMS AUDIT ===")
banned_words = ["mock", "stub", "dummy", "fake", "placeholder", "TODO"]
for w in banned_words:
    matches = re.findall(rf".*{w}.*", content, re.IGNORECASE)
    print(f"Occurrences of '{w}': {len(matches)}")
    for m in matches:
        print(f"   -> {m.strip()}")

print("\n=== 5. CHUNK LOG AUDIT ===")
chunk_logs = glob.glob(r"D:\__CoChem\GitHub-Repo\CoChem-BASE\.docs\.audit\.logs\*chunk*") + \
             glob.glob(r"D:\__CoChem\GitHub-Repo\CoChem-BASE\.docs\.audit\**\*chunk*", recursive=True)
print("Chunk files found:", chunk_logs)

print("\n=== 6. TRASH PATH COMPARISON IN OTHER AGENTS ===")
for p in glob.glob(r"D:\__CoChem\GitHub-Repo\CoChem-BASE\.agents\*.md"):
    with open(p, "r", encoding="utf-8", errors="ignore") as f:
        c = f.read()
    t_matches = re.findall(r"[^\s\(\)\[\]\"\'\`]*trash[^\s\(\)\[\]\"\'\`]*", c, re.IGNORECASE)
    if t_matches:
        print(f"{os.path.basename(p)}: {set(t_matches)}")
