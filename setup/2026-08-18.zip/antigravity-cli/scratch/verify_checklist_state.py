from pathlib import Path

repo_root = Path(r"D:\__CoChem\GitHub-Repo")
bp1 = (repo_root / "CoChem_Draco_Blueprint.md").read_text(encoding="utf-8")
bp2 = (repo_root / "GitHub-Repo_Draco_Blueprint.md").read_text(encoding="utf-8")

# Checkboxes
checked1 = [line for line in bp1.splitlines() if "[x]" in line.lower()]
checked2 = [line for line in bp2.splitlines() if "[x]" in line.lower()]
unchecked1 = [line for line in bp1.splitlines() if "[ ]" in line]
unchecked2 = [line for line in bp2.splitlines() if "[ ]" in line]

print(f"BP1 Checked: {len(checked1)}, Unchecked: {len(unchecked1)}")
print(f"BP2 Checked: {len(checked2)}, Unchecked: {len(unchecked2)}")

# Check for any execution artifacts / logs in blueprints
has_execution_logs = "PASSED" in bp1 or "FAILED" in bp1 or "AssertionError" in bp1
print(f"Has execution logs/status in blueprint: {has_execution_logs}")

