import os
import json
import glob
import re

repo = r'D:\__CoChem\GitHub-Repo'

# Find all notebooks
nbs = glob.glob(os.path.join(repo, '**', '*.ipynb'), recursive=True)
nbs = [f for f in nbs if '.venv' not in f and 'site-packages' not in f and '.trash' not in f]
nbs.sort()

out_file = r'C:\Users\ansac\.gemini\antigravity-cli\scratch\ui_widgets_analysis.txt'

with open(out_file, 'w', encoding='utf-8') as out:
    out.write(f"Total Notebooks analyzed: {len(nbs)}\n")
    for nb_path in nbs:
        rel = os.path.relpath(nb_path, repo)
        with open(nb_path, 'r', encoding='utf-8') as f:
            nb = json.load(f)
        cells = nb.get('cells', [])
        out.write(f"\n========================================================\n")
        out.write(f"MODULE NOTEBOOK: {rel}\n")
        out.write(f"Cells count: {len(cells)}\n")
        out.write(f"========================================================\n")
        for idx, c in enumerate(cells):
            ctype = c.get('cell_type')
            src = ''.join(c.get('source', []))
            widgets = re.findall(r'widgets\.\w+', src)
            buttons = re.findall(r'Button\([^)]*\)', src)
            dropdowns = re.findall(r'Dropdown\([^)]*\)', src)
            textboxes = re.findall(r'Text\([^)]*\)|Textarea\([^)]*\)', src)
            methods = re.findall(r'def \w+\([^)]*\):', src)
            classes = re.findall(r'class \w+[^:]*:', src)
            imports = [line for line in src.split('\n') if line.startswith('import ') or line.startswith('from ')]
            
            out.write(f"Cell {idx:02d} [{ctype}] ({len(src.splitlines())} lines):\n")
            if ctype == 'markdown':
                headers = [l for l in src.splitlines() if l.startswith('#')]
                out.write(f"  Markdown Headers: {headers[:3]}\n")
            else:
                if widgets:
                    out.write(f"  Widgets: {set(widgets)}\n")
                if buttons:
                    out.write(f"  Buttons: {len(buttons)}\n")
                if dropdowns:
                    out.write(f"  Dropdowns: {len(dropdowns)}\n")
                if classes:
                    out.write(f"  Classes: {classes[:3]}\n")
                if methods:
                    out.write(f"  Methods: {methods[:3]}\n")
                if imports:
                    out.write(f"  Imports: {imports[:3]}\n")
                
                # Check for specific interactive logic or method matrix keywords
                keywords = ['CREST', 'GOAT', 'defgrid', 'D3', 'D4', 'spin', 'S-squared', 'ORCA', 'xTB', 'Langevin', 'SHAKE', 'Counterpoise', 'BSSE', 'Boltzmann']
                found_kw = [kw for kw in keywords if re.search(r'\b' + re.escape(kw) + r'\b', src, re.I)]
                if found_kw:
                    out.write(f"  Method Matrix / Physics Keywords: {found_kw}\n")

print(f"Analysis complete, saved to {out_file}")
