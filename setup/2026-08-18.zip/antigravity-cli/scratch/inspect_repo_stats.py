import os
import re
from pathlib import Path

repo_root = Path(r"D:\__CoChem\GitHub-Repo")

# Count test files and test functions across repo
test_files = []
total_test_functions = 0

for root, dirs, files in os.walk(repo_root):
    if any(x in root for x in [".venv", ".conda", ".git", ".trash"]):
        continue
    for f in files:
        if (f.startswith("test_") or f.endswith("_test.py")) and f.endswith(".py"):
            fpath = os.path.join(root, f)
            rel_path = os.path.relpath(fpath, repo_root).replace("\\", "/")
            test_files.append(rel_path)
            try:
                content = open(fpath, "r", encoding="utf-8", errors="ignore").read()
                # Count def test_
                tests = re.findall(r"def\s+test_", content)
                total_test_functions += len(tests)
            except Exception as e:
                pass

print(f"Total test .py files: {len(test_files)}")
print(f"Total test functions: {total_test_functions}")

# List all notebooks
notebooks = []
for root, dirs, files in os.walk(repo_root):
    if any(x in root for x in [".venv", ".conda", ".git", ".trash"]):
        continue
    for f in files:
        if f.endswith(".ipynb"):
            rel_path = os.path.relpath(os.path.join(root, f), repo_root).replace("\\", "/")
            notebooks.append(rel_path)

print(f"Total non-trash/non-venv notebooks: {len(notebooks)}")
for nb in sorted(notebooks):
    print(f"  - {nb}")

