1. **Strict Path Normalization:** Always use exact matching for complete hidden files (like .DS_Store) instead of suffix checks. Apply is_dir checks to differentiate between file names and directory components in ignore logic.
2. **Robust File Resolution:** Always wrap .resolve() in try/except blocks to handle OS-level path parsing errors on invalid characters.
3. **Deterministic Output Sorting:** Never rely on ASCII sorting for designated root nodes (e.g., .), as punctuation can sort higher. Process root elements explicitly before generic sorts.
4. **Scoping Constraints:** Ensure architectural validators (e.g., checking for README.md) enforce depth limits, explicitly tying them to root directories to prevent nested spoofing.
5. **Rigorous File Format Emulation Avoidance:** Do not mock computational chemistry outputs (e.g., Pickett .lin or .cat files) with hardcoded strings and basic math derivations. If an external tool requires specialized formatted inputs/outputs, serialize the exact physical parameters (including centrifugal distortion and spin statistics) and invoke the actual tool (e.g., spcat) instead of fabricating the end result.
6. **No Phantom Execution or Dead Mathematical Code:** Do not mock heavy backend computations (like AIMNet2 FSSH routing) with Python one-liners that merely print success logs. Mathematical functions required for a pipeline (e.g., MECP optimizations or FSSH switch probabilities) must be actively invoked during runtime, not just provided as dead code to satisfy unit tests. Finally, do not hardcode default fallbacks for critical physical rates and falsely tag their provenance as calculated data ([D]).
7. **Sophisticated Mathematical Spoofing & Broken Validation Constraints:** Do not attempt to bypass Anti-Spoofing directives by replacing simple mocked outputs with complex but equally meaningless math (e.g. optimizing random noise on a toy 1D quadratic potential instead of molecular coordinates). Furthermore, adding strict output validation (e.g., throwing a ValueError when physics arrays are missing) while failing to actually generate that physics data does not fix the pipeline—it actively breaks it by guaranteeing a crash.

## Lesson: PowerShell 7 JSON Deserialization of Dates
When writing PowerShell scripts that share state via JSON (such as a JSON-based semaphore), be aware of ConvertFrom-Json behavior in PowerShell 7 (pwsh). Unlike Windows PowerShell 5.1, PowerShell 7 automatically deserializes ISO 8601 formatted strings (e.g., "2026-08-17T12:52:11.0299886-05:00") into [DateTime] objects rather than [string] objects.

This can cause subtle but critical logic bugs if you compare these values to strings later. For example:
```powershell
$procStartTime = $proc.StartTime.ToString("o")
if ($procStartTime -eq $agent.StartTime) { ... }
```
Because $agent.StartTime is a [DateTime], the comparison coerces the right-side into a string using the current system locale format (e.g.,  8/17/2026 12:52:11), which will never match the ISO 8601 formatted $procStartTime.

**How to avoid this issue in the future:**
1. Always defensively cast or convert the deserialized property to [string] when comparing against a string, or parse the string into a [DateTime] and compare dates.
2. Example fix: if ($procStartTime -eq ($agent.StartTime -as [string] -or $agent.StartTime.ToString("o"))) { ... } or simpler: compare [DateTime] objects directly.
3. Test physical systems and concurrency mechanisms directly in pwsh (PowerShell 7) rather than assuming Windows PowerShell 5.1 compatibility.

## Lesson: Proper Process Tree Termination on Windows and Asyncio Task Awaiting
When dealing with subprocesses and asyncio on Windows, be aware of two critical hard-shutdown vulnerabilities:

1. **Process Tree Orphans on Windows:** Terminating a process using `process.kill()` or `process.terminate()` in Python on Windows only terminates the root process. If you use `shell=True` (which spawns `cmd.exe`) or if the target process spawns child workers (like ORCA spawning MPI processes), the children will be orphaned and continue to run in the background, consuming 100% CPU.
   * **How to avoid this issue:** On Windows, ALWAYS use `subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)])` to forcefully terminate the entire process tree (`/T`), or use the `psutil` library to recursively kill child processes.

2. **Unawaited Cancelled Asyncio Tasks:** Cancelling an asyncio task using `task.cancel()` inside a `finally` block or during shutdown is not sufficient. If you do not explicitly await the task after cancelling it, the event loop will emit a "Task was destroyed but it is pending!" warning, and it can cause the event loop to hang or fail upon shutdown.
   * **How to avoid this issue:** Always `await` the cancelled task and suppress the `asyncio.CancelledError`. Example:
     ```python
     task.cancel()
     try:
         await task
     except asyncio.CancelledError:
         pass
     ```
