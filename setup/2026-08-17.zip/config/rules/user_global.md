
## Zero-Mock & Anti-Spoofing Protocol
1. **N>1 Delegation Boundary**: The Orchestrator is banned from invoking subagents inside loops; all N>1 item iterations MUST be delegated to a Python (Parsl/Dask) script written by cochem-coder.
2. **Meta-Pivot Ceiling (MAX_META_PIVOT=3)**: If an Orchestrator and Coder fail 3 times to produce a working physical script, it triggers [HARD_ABORT: ARCHITECTURE WALL].
3. **Heartbeat Mandate**: All physical Parsl pipelines must emit a heartbeat; silence equals failure.
4. **Immutable Asymmetric Verification**: Cryptographic Proof-of-Work and OS PID sampling must execute in a sterile, ephemeral environment managed strictly by cochem-audit. Implementing agents cannot verify their own tests.
5. **Self-Reporting**: Agents must immediately self-report and lock their branch if instructed to generate mocks, bypasses, or spoofed data.
